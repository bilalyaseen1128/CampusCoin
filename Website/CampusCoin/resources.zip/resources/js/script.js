const body = document.body;
const themeButton = document.getElementById("themeButton");
const menuButton = document.getElementById("menuButton");
const sidebar = document.getElementById("sidebar");

const savedTheme = localStorage.getItem("campuscoin-theme");

if (savedTheme === "dark") {
    body.classList.add("dark");
}

function updateThemeIcon() {
    if (!themeButton) return;
    themeButton.textContent = body.classList.contains("dark") ? "☀" : "☾";
}

updateThemeIcon();

if (themeButton) {
    themeButton.addEventListener("click", () => {
        body.classList.toggle("dark");

        localStorage.setItem(
            "campuscoin-theme",
            body.classList.contains("dark") ? "dark" : "light"
        );

        updateThemeIcon();
    });
}

if (menuButton && sidebar) {
    menuButton.addEventListener("click", () => {
        sidebar.classList.toggle("open");
    });
}

document.querySelectorAll(".nav-link").forEach(link => {
    link.addEventListener("click", () => {
        if (window.innerWidth <= 850 && sidebar) {
            sidebar.classList.remove("open");
        }
    });
});

const currentPage = window.location.pathname.split("/").pop();

document.querySelectorAll(".nav-link").forEach(link => {
    const linkPage = link.getAttribute("href");

    if (linkPage === currentPage) {
        link.classList.add("active");
    }
});
