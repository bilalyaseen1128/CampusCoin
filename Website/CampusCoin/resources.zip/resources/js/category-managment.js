const managementPopup = document.getElementById("managementPopup");
const managementPopupClose = document.getElementById("managementPopupClose");
const popupTitle = document.getElementById("popupTitle");
const popupDescription = document.getElementById("popupDescription");
const popupIcon = document.getElementById("popupIcon");
const popupItems = document.getElementById("popupItems");

const managementCategories = {
    academics: {
        title: "Academics",
        description: "Academic related expenses",
        icon: "fa-book",
        items: [
            "Books",
            "Tuition",
            "Stationery"
        ]
    },

    subscriptions: {
        title: "Subscriptions",
        description: "Streaming services and applications",
        icon: "fa-mobile-screen",
        items: [
            "Streaming",
            "Apps"
        ]
    },

    entertainment: {
        title: "Entertainment",
        description: "Movies and outing related expenses",
        icon: "fa-film",
        items: [
            "Movies",
            "Outings"
        ]
    }
};

document.querySelectorAll(".management-clickable").forEach(row => {

    row.addEventListener("click", () => {

        const category = row.dataset.category;
        const data = managementCategories[category];

        if (!data || !managementPopup) {
            return;
        }

        popupTitle.textContent = data.title;
        popupDescription.textContent = data.description;

        popupIcon.innerHTML = `
            <i class="fa-solid ${data.icon}"></i>
        `;

        popupItems.innerHTML = data.items.map(item => `
            <div class="popup-item">
                <i class="fa-solid fa-check"></i>
                <span>${item}</span>
            </div>
        `).join("");

        managementPopup.classList.add("show");
    });

});


if (managementPopupClose) {

    managementPopupClose.addEventListener("click", () => {
        managementPopup.classList.remove("show");
    });

}


if (managementPopup) {

    managementPopup.addEventListener("click", event => {

        if (event.target === managementPopup) {
            managementPopup.classList.remove("show");
        }

    });

}


document.addEventListener("keydown", event => {

    if (event.key === "Escape" && managementPopup) {
        managementPopup.classList.remove("show");
    }

});


const managementAddButtons = document.querySelectorAll(".management-add-btn");
const managementFormCard = document.querySelector(".management-form-card");
const managementCategoryName = document.getElementById("managementCategoryName");
const managementCategoryType = document.getElementById("managementCategoryType");

managementAddButtons.forEach(button => {

    button.addEventListener("click", () => {

        const type = button.dataset.type;

        if (managementCategoryType) {
            managementCategoryType.value = type;
        }

        if (managementFormCard) {

            managementFormCard.scrollIntoView({
                behavior: "smooth",
                block: "center"
            });

        }

        setTimeout(() => {

            if (managementCategoryName) {
                managementCategoryName.focus();
            }

        }, 500);

    });

});


const newManagementCategoryForm =
    document.getElementById("newManagementCategoryForm");

const managementCancelBtn =
    document.getElementById("managementCancelBtn");


if (managementCancelBtn) {

    managementCancelBtn.addEventListener("click", () => {

        newManagementCategoryForm.reset();

    });

}


if (newManagementCategoryForm) {

    newManagementCategoryForm.addEventListener("submit", event => {

        event.preventDefault();

        const name = managementCategoryName.value.trim();
        const type = managementCategoryType.value;

        if (!name) {

            managementCategoryName.focus();
            return;

        }

        if (!type) {

            managementCategoryType.focus();
            return;

        }

        alert(
            `${name} has been added as an ${type} category.`
        );

        newManagementCategoryForm.reset();

    });

}