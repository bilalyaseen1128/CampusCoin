<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Categories | CampusCoin</title>

    <!-- Google Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <!-- CSS -->
<style>

:root {

    --primary: #7c5cff;
    --primary-dark: #6546e8;
    --primary-light: #9b83ff;

    --income: #22c55e;
    --income-bg: rgba(34, 197, 94, 0.12);

    --expense: #ef4444;
    --expense-bg: rgba(239, 68, 68, 0.12);

    --body: #f5f6fa;
    --surface: #ffffff;
    --surface-2: #f8f9fc;

    --sidebar: #ffffff;

    --text: #171923;
    --text-light: #737887;

    --border: #e5e7eb;

    --shadow: 0 10px 30px rgba(20, 20, 40, 0.07);

    --radius: 16px;

    --transition: 0.3s ease;
}



body.dark {

    --body: #0f1117;
    --surface: #181b24;
    --surface-2: #20242f;

    --sidebar: #141720;

    --text: #f5f7fa;
    --text-light: #a7adba;

    --border: #303542;

    --shadow: 0 10px 30px rgba(0, 0, 0, 0.35);

    background: var(--body);
    color: var(--text);
}


/* Dark mode specific elements */

body.dark .topbar {
    background: var(--surface);
}

body.dark .sidebar {
    background: var(--sidebar);
}

body.dark .stat-card,
body.dark .category-card,
body.dark .category-tools,
body.dark .empty-state,
body.dark .modal,
body.dark .toast {
    background: var(--surface);
    border-color: var(--border);
}

body.dark .search-box input,
body.dark .input-wrapper input,
body.dark .theme-btn,
body.dark .filter-btn,
body.dark .cancel-btn,
body.dark .close-modal,
body.dark .menu-btn {
    background: var(--surface-2);
    color: var(--text);
    border-color: var(--border);
}

body.dark .nav-item:hover {
    background: var(--surface-2);
}

body.dark .nav-item.active {
    background: rgba(124, 92, 255, 0.18);
}

body.dark .category-card:hover,
body.dark .stat-card:hover {
    box-shadow: 0 12px 35px rgba(0, 0, 0, 0.35);
}

   


/* ================= RESET ================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}


body {

    font-family: "Inter", sans-serif;

    background: var(--body);

    color: var(--text);

    min-height: 100vh;

    transition:
        background var(--transition),
        color var(--transition);
}


button,
input {
    font-family: inherit;
}


button {
    cursor: pointer;
}


a {
    text-decoration: none;
    color: inherit;
}


/* ================= SIDEBAR ================= */

.sidebar {

    position: fixed;

    top: 0;
    left: 0;

    width: 260px;
    height: 100vh;

    background: var(--sidebar);

    border-right: 1px solid var(--border);

    display: flex;

    flex-direction: column;

    padding: 25px 16px;

    z-index: 1000;

    transition:
        background var(--transition),
        transform var(--transition);
}


/* LOGO */

.logo-area {

    display: flex;

    align-items: center;

    gap: 12px;

    padding: 5px 10px 30px;
}


.logo-icon {

    width: 45px;
    height: 45px;

    border-radius: 13px;

    display: flex;

    align-items: center;
    justify-content: center;

    background:
        linear-gradient(
            135deg,
            var(--primary),
            var(--primary-light)
        );

    color: white;

    font-size: 20px;
}


.logo-text h2 {

    font-size: 20px;

    font-weight: 800;
}


.logo-text h2 span {
    color: var(--primary);
}


.logo-text p {

    color: var(--text-light);

    font-size: 10px;

    margin-top: 2px;
}


/* NAV */

.sidebar-nav {

    display: flex;

    flex-direction: column;

    gap: 5px;
}


.nav-item {

    display: flex;

    align-items: center;

    gap: 13px;

    padding: 12px 14px;

    border-radius: 11px;

    color: var(--text-light);

    font-size: 13px;

    font-weight: 500;

    transition: var(--transition);
}


.nav-item i {

    width: 20px;

    text-align: center;
}


.nav-item:hover {

    background: var(--surface-2);

    color: var(--primary);
}


.nav-item.active {

    background: rgba(124, 92, 255, 0.12);

    color: var(--primary);

    font-weight: 700;
}


.sidebar-bottom {

    margin-top: auto;

    border-top: 1px solid var(--border);

    padding-top: 15px;
}


.logout:hover {
    color: var(--expense);
}


/* ================= MAIN ================= */

.main-content {

    margin-left: 260px;

    min-height: 100vh;
}


/* ================= TOPBAR ================= */

.topbar {

    height: 90px;

    background: var(--surface);

    border-bottom: 1px solid var(--border);

    padding: 0 35px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    position: sticky;

    top: 0;

    z-index: 100;

    transition: var(--transition);
}


.page-heading h1 {

    font-size: 22px;

    font-weight: 800;
}


.page-heading p {

    margin-top: 5px;

    color: var(--text-light);

    font-size: 12px;
}


.topbar-actions {

    display: flex;

    align-items: center;

    gap: 20px;
}


/* THEME */

.theme-btn {

    width: 40px;
    height: 40px;

    border: 1px solid var(--border);

    background: var(--surface-2);

    color: var(--text);

    border-radius: 11px;

    transition: var(--transition);
}


.theme-btn:hover {

    color: var(--primary);

    border-color: var(--primary);
}


/* PROFILE */

.profile-mini {

    display: flex;

    align-items: center;

    gap: 9px;
}


.profile-avatar {

    width: 39px;
    height: 39px;

    border-radius: 50%;

    display: flex;

    align-items: center;
    justify-content: center;

    background:
        linear-gradient(
            135deg,
            var(--primary),
            var(--primary-light)
        );

    color: white;

    font-weight: 700;
}


.profile-info {

    display: flex;

    flex-direction: column;

    gap: 2px;
}


.profile-info strong {
    font-size: 12px;
}


.profile-info span {

    color: var(--text-light);

    font-size: 10px;
}


/* MOBILE MENU */

.menu-btn {

    display: none;

    width: 40px;
    height: 40px;

    border: 0;

    background: var(--surface-2);

    color: var(--text);

    border-radius: 10px;
}


/* ================= CONTENT ================= */

.content {

    padding: 30px 35px 50px;
}


/* ================= STATS ================= */

.stats-grid {

    display: grid;

    grid-template-columns: repeat(4, 1fr);

    gap: 18px;

    margin-bottom: 35px;
}


.stat-card {

    background: var(--surface);

    border: 1px solid var(--border);

    border-radius: var(--radius);

    padding: 20px;

    display: flex;

    align-items: center;

    gap: 15px;

    box-shadow: var(--shadow);

    transition: var(--transition);
}


.stat-card:hover {

    transform: translateY(-3px);
}


.stat-icon {

    width: 48px;
    height: 48px;

    border-radius: 13px;

    display: flex;

    align-items: center;
    justify-content: center;
}


.stat-icon.total {

    background: rgba(124, 92, 255, 0.12);

    color: var(--primary);
}


.stat-icon.income {

    background: var(--income-bg);

    color: var(--income);
}


.stat-icon.expense {

    background: var(--expense-bg);

    color: var(--expense);
}


.stat-icon.custom {

    background: rgba(59, 130, 246, 0.12);

    color: #3b82f6;
}


.stat-card span {

    display: block;

    color: var(--text-light);

    font-size: 11px;

    margin-bottom: 5px;
}


.stat-card h3 {

    font-size: 23px;

    font-weight: 800;
}


/* ================= SECTION ================= */

.section-header {

    display: flex;

    align-items: center;

    justify-content: space-between;

    margin-bottom: 20px;
}


.section-header h2 {

    font-size: 18px;

    font-weight: 800;
}


.section-header p {

    color: var(--text-light);

    font-size: 12px;

    margin-top: 4px;
}


/* ADD CATEGORY */

.add-category-btn {

    border: 0;

    background:
        linear-gradient(
            135deg,
            var(--primary),
            var(--primary-light)
        );

    color: white;

    padding: 12px 18px;

    border-radius: 11px;

    font-size: 12px;

    font-weight: 700;

    display: flex;

    align-items: center;

    gap: 8px;

    transition: var(--transition);
}


.add-category-btn:hover {

    transform: translateY(-2px);
}


/* ================= SEARCH ================= */

.category-tools {

    background: var(--surface);

    border: 1px solid var(--border);

    border-radius: var(--radius);

    padding: 15px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 20px;

    margin-bottom: 20px;
}


.search-box {

    position: relative;

    width: 330px;
}


.search-box i {

    position: absolute;

    left: 14px;
    top: 50%;

    transform: translateY(-50%);

    color: var(--text-light);
}


.search-box input {

    width: 100%;

    height: 42px;

    border: 1px solid var(--border);

    background: var(--surface-2);

    color: var(--text);

    border-radius: 10px;

    padding: 0 15px 0 38px;

    outline: none;
}


.search-box input:focus {

    border-color: var(--primary);
}


/* FILTER */

.filter-buttons {

    display: flex;

    gap: 7px;
}


.filter-btn {

    border: 1px solid var(--border);

    background: var(--surface-2);

    color: var(--text-light);

    padding: 9px 13px;

    border-radius: 9px;

    font-size: 11px;

    font-weight: 600;
}


.filter-btn.active {

    background: var(--primary);

    color: white;

    border-color: var(--primary);
}


/* ================= CATEGORY GRID ================= */

.category-grid {

    display: grid;

    grid-template-columns: repeat(3, 1fr);

    gap: 15px;
}


.category-card {

    background: var(--surface);

    border: 1px solid var(--border);

    border-radius: var(--radius);

    padding: 18px;

    display: flex;

    align-items: center;

    gap: 14px;

    min-height: 95px;

    box-shadow: var(--shadow);

    transition: var(--transition);
}


.category-card:hover {

    transform: translateY(-3px);
}


.category-icon {

    width: 47px;
    height: 47px;

    border-radius: 13px;

    display: flex;

    align-items: center;
    justify-content: center;

    flex-shrink: 0;
}


.income-card .category-icon {

    background: var(--income-bg);

    color: var(--income);
}


.expense-card .category-icon {

    background: var(--expense-bg);

    color: var(--expense);
}


.category-details h3 {

    font-size: 13px;

    margin-bottom: 5px;
}


.category-details span {

    color: var(--text-light);

    font-size: 10px;
}


.income-card .category-details span {
    color: var(--income);
}


.expense-card .category-details span {
    color: var(--expense);
}


.category-menu {

    margin-left: auto;

    color: var(--text-light);

    font-size: 12px;
}


/* DELETE */

.custom-delete {

    width: 31px;
    height: 31px;

    border: 0;

    border-radius: 8px;

    background: var(--expense-bg);

    color: var(--expense);
}


/* ================= EMPTY ================= */

.empty-state {

    display: none;

    text-align: center;

    padding: 70px 20px;

    background: var(--surface);

    border: 1px solid var(--border);

    border-radius: var(--radius);
}


.empty-state.show {
    display: block;
}


.empty-icon {

    width: 60px;
    height: 60px;

    margin: auto auto 15px;

    border-radius: 16px;

    display: flex;

    align-items: center;
    justify-content: center;

    background: rgba(124, 92, 255, 0.1);

    color: var(--primary);

    font-size: 22px;
}


.empty-state h3 {

    font-size: 15px;

    margin-bottom: 7px;
}


.empty-state p {

    color: var(--text-light);

    font-size: 12px;
}


/* ================= MODAL ================= */

.modal-overlay {

    position: fixed;

    inset: 0;

    background: rgba(10, 10, 20, 0.65);

    backdrop-filter: blur(5px);

    display: flex;

    align-items: center;
    justify-content: center;

    padding: 20px;

    opacity: 0;

    visibility: hidden;

    transition: var(--transition);

    z-index: 2000;
}


.modal-overlay.show {

    opacity: 1;

    visibility: visible;
}


.modal {

    position: relative;

    width: 100%;

    max-width: 450px;

    background: var(--surface);

    border: 1px solid var(--border);

    border-radius: 20px;

    padding: 30px;

    box-shadow: 0 25px 80px rgba(0, 0, 0, 0.25);
}


.close-modal {

    position: absolute;

    top: 18px;
    right: 18px;

    width: 34px;
    height: 34px;

    border: 0;

    background: var(--surface-2);

    color: var(--text-light);

    border-radius: 9px;
}


.modal-icon {

    width: 55px;
    height: 55px;

    border-radius: 15px;

    display: flex;

    align-items: center;
    justify-content: center;

    background: rgba(124, 92, 255, 0.12);

    color: var(--primary);

    margin-bottom: 18px;
}


.modal h2 {

    font-size: 20px;

    margin-bottom: 7px;
}


.modal > p {

    color: var(--text-light);

    font-size: 12px;

    margin-bottom: 25px;
}


/* FORM */

.form-group {

    margin-bottom: 22px;
}


.form-group label {

    display: block;

    font-size: 12px;

    font-weight: 700;

    margin-bottom: 8px;
}


.input-wrapper {

    position: relative;
}


.input-wrapper i {

    position: absolute;

    left: 14px;
    top: 50%;

    transform: translateY(-50%);

    color: var(--text-light);
}


.input-wrapper input {

    width: 100%;

    height: 45px;

    border: 1px solid var(--border);

    background: var(--surface-2);

    color: var(--text);

    border-radius: 10px;

    padding: 0 14px 0 38px;

    outline: none;
}


.type-options {

    display: grid;

    grid-template-columns: 1fr 1fr;

    gap: 10px;
}


.type-option input {
    display: none;
}


.type-option span {

    height: 48px;

    border: 1px solid var(--border);

    border-radius: 10px;

    display: flex;

    align-items: center;
    justify-content: center;

    gap: 8px;

    color: var(--text-light);

    font-size: 11px;

    font-weight: 700;

    cursor: pointer;
}


.income-option input:checked + span {

    border-color: var(--income);

    background: var(--income-bg);

    color: var(--income);
}


.expense-option input:checked + span {

    border-color: var(--expense);

    background: var(--expense-bg);

    color: var(--expense);
}


/* MODAL BUTTONS */

.modal-actions {

    display: flex;

    justify-content: flex-end;

    gap: 10px;

    margin-top: 28px;
}


.cancel-btn,
.save-btn {

    padding: 11px 17px;

    border-radius: 9px;

    font-size: 11px;

    font-weight: 700;
}


.cancel-btn {

    border: 1px solid var(--border);

    background: var(--surface-2);

    color: var(--text-light);
}


.save-btn {

    border: 0;

    background: var(--primary);

    color: white;
}


/* ================= TOAST ================= */

.toast {

    position: fixed;

    right: 25px;
    bottom: 25px;

    min-width: 280px;

    background: var(--surface);

    border: 1px solid var(--border);

    box-shadow: 0 15px 45px rgba(0, 0, 0, 0.18);

    border-radius: 13px;

    padding: 14px;

    display: flex;

    align-items: center;

    gap: 12px;

    transform: translateX(130%);

    transition: 0.4s ease;

    z-index: 3000;
}


.toast.show {
    transform: translateX(0);
}


.toast-icon {

    width: 35px;
    height: 35px;

    border-radius: 9px;

    background: var(--income-bg);

    color: var(--income);

    display: flex;

    align-items: center;
    justify-content: center;
}


.toast strong {

    display: block;

    font-size: 12px;

    margin-bottom: 3px;
}


.toast p {

    color: var(--text-light);

    font-size: 10px;
}


/* ================= RESPONSIVE ================= */

@media (max-width: 1100px) {

    .stats-grid {
        grid-template-columns: repeat(2, 1fr);
    }

    .category-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}


@media (max-width: 850px) {

    .sidebar {

        transform: translateX(-100%);
    }

    .sidebar.open {

        transform: translateX(0);
    }

    .main-content {

        margin-left: 0;
    }

    .menu-btn {

        display: block;
    }

    .topbar {

        padding: 0 20px;
    }

    .page-heading p {

        display: none;
    }

    .content {

        padding: 25px 20px;
    }
}


@media (max-width: 600px) {

    .stats-grid {

        grid-template-columns: 1fr;
    }

    .category-grid {

        grid-template-columns: 1fr;
    }

    .category-tools {

        flex-direction: column;

        align-items: stretch;
    }

    .search-box {

        width: 100%;
    }

    .filter-buttons {

        width: 100%;
    }

    .filter-btn {

        flex: 1;
    }

    .section-header {

        flex-direction: column;

        align-items: stretch;
    }

    .add-category-btn {

        justify-content: center;
    }

    .profile-info {

        display: none;
    }

    .type-options {

        grid-template-columns: 1fr;
    }
}
</style>
</head>

<body>

    <!-- ================= SIDEBAR ================= -->

    <aside class="sidebar" id="sidebar">

        <div class="logo-area">

            <div class="logo-icon">
                <i class="fa-solid fa-coins"></i>
            </div>

            <div class="logo-text">
                <h2>Campus<span>Coin</span></h2>
                <p>Student Finance</p>
            </div>

        </div>


        <nav class="sidebar-nav">

            <a href="#" class="nav-item">
                <i class="fa-solid fa-chart-line"></i>
                <span>Dashboard</span>
            </a>

            <a href="#" class="nav-item">
                <i class="fa-solid fa-wallet"></i>
                <span>Income & Expenses</span>
            </a>

            <a href="#" class="nav-item active">
                <i class="fa-solid fa-layer-group"></i>
                <span>Categories</span>
            </a>

            <a href="#" class="nav-item">
                <i class="fa-solid fa-bullseye"></i>
                <span>Budget Goals</span>
            </a>

            <a href="#" class="nav-item">
                <i class="fa-solid fa-chart-pie"></i>
                <span>Reports & Insights</span>
            </a>

            <a href="#" class="nav-item">
                <i class="fa-solid fa-lightbulb"></i>
                <span>Saving Tips</span>
            </a>

        </nav>


        <div class="sidebar-bottom">

            <a href="#" class="nav-item">
                <i class="fa-solid fa-user"></i>
                <span>Profile</span>
            </a>

            <a href="#" class="nav-item logout">
                <i class="fa-solid fa-right-from-bracket"></i>
                <span>Logout</span>
            </a>

        </div>

    </aside>


    <!-- ================= MAIN CONTENT ================= -->

    <main class="main-content">

        <!-- TOP BAR -->

        <header class="topbar">

            <button class="menu-btn" id="menuBtn">
                <i class="fa-solid fa-bars"></i>
            </button>

            <div class="page-heading">
                <h1>Category Management</h1>
                <p>Organize your income and expenses with personal categories.</p>
            </div>


            <div class="topbar-actions">

                <button class="theme-btn"
                        id="themeToggle"
                        title="Change Theme">

                    <i class="fa-solid fa-moon"></i>

                </button>


                <div class="profile-mini">

                    <div class="profile-avatar">
                        H
                    </div>

                    <div class="profile-info">
                        <strong>Hareem</strong>
                        <span>Student</span>
                    </div>

                </div>

            </div>

        </header>


        <!-- ================= CONTENT ================= -->

        <section class="content">


            <!-- STATISTICS -->

            <div class="stats-grid">

                <div class="stat-card">

                    <div class="stat-icon total">
                        <i class="fa-solid fa-layer-group"></i>
                    </div>

                    <div>
                        <span>Total Categories</span>
                        <h3 id="totalCategories">12</h3>
                    </div>

                </div>


                <div class="stat-card">

                    <div class="stat-icon income">
                        <i class="fa-solid fa-arrow-trend-up"></i>
                    </div>

                    <div>
                        <span>Income Categories</span>
                        <h3 id="incomeCount">5</h3>
                    </div>

                </div>


                <div class="stat-card">

                    <div class="stat-icon expense">
                        <i class="fa-solid fa-arrow-trend-down"></i>
                    </div>

                    <div>
                        <span>Expense Categories</span>
                        <h3 id="expenseCount">7</h3>
                    </div>

                </div>


                <div class="stat-card">

                    <div class="stat-icon custom">
                        <i class="fa-solid fa-user-plus"></i>
                    </div>

                    <div>
                        <span>My Categories</span>
                        <h3 id="customCount">0</h3>
                    </div>

                </div>

            </div>


            <!-- SECTION HEADER -->

            <div class="section-header">

                <div>
                    <h2>My Categories</h2>
                    <p>Manage your income and expense categories.</p>
                </div>


                <button class="add-category-btn"
                        id="openModal">

                    <i class="fa-solid fa-plus"></i>
                    Add Category

                </button>

            </div>


            <!-- SEARCH AND FILTER -->

            <div class="category-tools">

                <div class="search-box">

                    <i class="fa-solid fa-magnifying-glass"></i>

                    <input
                        type="text"
                        id="searchInput"
                        placeholder="Search categories..."
                    >

                </div>


                <div class="filter-buttons">

                    <button class="filter-btn active"
                            data-filter="all">
                        All
                    </button>

                    <button class="filter-btn"
                            data-filter="income">

                        <i class="fa-solid fa-arrow-trend-up"></i>
                        Income

                    </button>

                    <button class="filter-btn"
                            data-filter="expense">

                        <i class="fa-solid fa-arrow-trend-down"></i>
                        Expense

                    </button>

                </div>

            </div>


            <!-- CATEGORY CARDS -->

            <div class="category-grid" id="categoryGrid">


                <!-- INCOME -->

                <div class="category-card income-card"
                     data-type="income">

                    <div class="category-icon">
                        <i class="fa-solid fa-hand-holding-dollar"></i>
                    </div>

                    <div class="category-details">
                        <h3>Allowance</h3>
                        <span>Income</span>
                    </div>

                    <div class="category-menu">
                        <i class="fa-solid fa-lock"></i>
                    </div>

                </div>


                <div class="category-card income-card"
                     data-type="income">

                    <div class="category-icon">
                        <i class="fa-solid fa-briefcase"></i>
                    </div>

                    <div class="category-details">
                        <h3>Part-time Job</h3>
                        <span>Income</span>
                    </div>

                    <div class="category-menu">
                        <i class="fa-solid fa-lock"></i>
                    </div>

                </div>


                <div class="category-card income-card"
                     data-type="income">

                    <div class="category-icon">
                        <i class="fa-solid fa-graduation-cap"></i>
                    </div>

                    <div class="category-details">
                        <h3>Scholarship</h3>
                        <span>Income</span>
                    </div>

                    <div class="category-menu">
                        <i class="fa-solid fa-lock"></i>
                    </div>

                </div>


                <div class="category-card income-card"
                     data-type="income">

                    <div class="category-icon">
                        <i class="fa-solid fa-gift"></i>
                    </div>

                    <div class="category-details">
                        <h3>Gift</h3>
                        <span>Income</span>
                    </div>

                    <div class="category-menu">
                        <i class="fa-solid fa-lock"></i>
                    </div>

                </div>


                <div class="category-card income-card"
                     data-type="income">

                    <div class="category-icon">
                        <i class="fa-solid fa-money-bill-wave"></i>
                    </div>

                    <div class="category-details">
                        <h3>Other Income</h3>
                        <span>Income</span>
                    </div>

                    <div class="category-menu">
                        <i class="fa-solid fa-lock"></i>
                    </div>

                </div>


                <!-- EXPENSE -->

                <div class="category-card expense-card"
                     data-type="expense">

                    <div class="category-icon">
                        <i class="fa-solid fa-utensils"></i>
                    </div>

                    <div class="category-details">
                        <h3>Food</h3>
                        <span>Expense</span>
                    </div>

                    <div class="category-menu">
                        <i class="fa-solid fa-lock"></i>
                    </div>

                </div>


                <div class="category-card expense-card"
                     data-type="expense">

                    <div class="category-icon">
                        <i class="fa-solid fa-bus"></i>
                    </div>

                    <div class="category-details">
                        <h3>Transport</h3>
                        <span>Expense</span>
                    </div>

                    <div class="category-menu">
                        <i class="fa-solid fa-lock"></i>
                    </div>

                </div>


                <div class="category-card expense-card"
                     data-type="expense">

                    <div class="category-icon">
                        <i class="fa-solid fa-house"></i>
                    </div>

                    <div class="category-details">
                        <h3>Hostel / Rent</h3>
                        <span>Expense</span>
                    </div>

                    <div class="category-menu">
                        <i class="fa-solid fa-lock"></i>
                    </div>

                </div>


                <div class="category-card expense-card"
                     data-type="expense">

                    <div class="category-icon">
                        <i class="fa-solid fa-book"></i>
                    </div>

                    <div class="category-details">
                        <h3>Academics</h3>
                        <span>Expense</span>
                    </div>

                    <div class="category-menu">
                        <i class="fa-solid fa-lock"></i>
                    </div>

                </div>


                <div class="category-card expense-card"
                     data-type="expense">

                    <div class="category-icon">
                        <i class="fa-solid fa-mobile-screen"></i>
                    </div>

                    <div class="category-details">
                        <h3>Subscriptions</h3>
                        <span>Expense</span>
                    </div>

                    <div class="category-menu">
                        <i class="fa-solid fa-lock"></i>
                    </div>

                </div>


                <div class="category-card expense-card"
                     data-type="expense">

                    <div class="category-icon">
                        <i class="fa-solid fa-film"></i>
                    </div>

                    <div class="category-details">
                        <h3>Entertainment</h3>
                        <span>Expense</span>
                    </div>

                    <div class="category-menu">
                        <i class="fa-solid fa-lock"></i>
                    </div>

                </div>


                <div class="category-card expense-card"
                     data-type="expense">

                    <div class="category-icon">
                        <i class="fa-solid fa-box"></i>
                    </div>

                    <div class="category-details">
                        <h3>Miscellaneous</h3>
                        <span>Expense</span>
                    </div>

                    <div class="category-menu">
                        <i class="fa-solid fa-lock"></i>
                    </div>

                </div>

            </div>


            <!-- EMPTY STATE -->

            <div class="empty-state" id="emptyState">

                <div class="empty-icon">
                    <i class="fa-solid fa-folder-open"></i>
                </div>

                <h3>No categories found</h3>

                <p>
                    Try another search or create a new category.
                </p>

            </div>

        </section>

    </main>


    <!-- ================= ADD CATEGORY MODAL ================= -->

    <div class="modal-overlay" id="modalOverlay">

        <div class="modal">

            <button class="close-modal"
                    id="closeModal">

                <i class="fa-solid fa-xmark"></i>

            </button>


            <div class="modal-icon">
                <i class="fa-solid fa-layer-group"></i>
            </div>


            <h2>Add New Category</h2>

            <p>
                Create a personal income or expense category.
            </p>


            <form id="categoryForm">

                <div class="form-group">

                    <label for="categoryName">
                        Category Name
                    </label>

                    <div class="input-wrapper">

                        <i class="fa-solid fa-tag"></i>

                        <input
                            type="text"
                            id="categoryName"
                            placeholder="e.g. Freelancing"
                            required
                        >

                    </div>

                </div>


                <div class="form-group">

                    <label>Category Type</label>

                    <div class="type-options">


                        <label class="type-option income-option">

                            <input
                                type="radio"
                                name="categoryType"
                                value="income"
                                checked
                            >

                            <span>
                                <i class="fa-solid fa-arrow-trend-up"></i>
                                Income
                            </span>

                        </label>


                        <label class="type-option expense-option">

                            <input
                                type="radio"
                                name="categoryType"
                                value="expense"
                            >

                            <span>
                                <i class="fa-solid fa-arrow-trend-down"></i>
                                Expense
                            </span>

                        </label>

                    </div>

                </div>


                <div class="modal-actions">

                    <button
                        type="button"
                        class="cancel-btn"
                        id="cancelModal">

                        Cancel

                    </button>


                    <button
                        type="submit"
                        class="save-btn">

                        <i class="fa-solid fa-plus"></i>

                        Add Category

                    </button>

                </div>

            </form>

        </div>

    </div>


    <!-- ================= TOAST ================= -->

    <div class="toast" id="toast">

        <div class="toast-icon">
            <i class="fa-solid fa-check"></i>
        </div>

        <div>
            <strong>Success</strong>
            <p id="toastMessage">
                Category added successfully.
            </p>
        </div>

    </div>


    <!-- JavaScript -->
    <script src="js/category-management.js"></script>
    <script src="js/script.js"></script>


</body>
</html>