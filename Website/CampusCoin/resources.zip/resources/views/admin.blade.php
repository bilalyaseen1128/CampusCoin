<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CampusCoin - Admin Control Panel</title>
</head>
<style>@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');

:root{
  --bg:#f5f7f4;--surface:#fff;--surface2:#eef3ee;--text:#17231b;--muted:#718078;
  --primary:#347c55;--primary-dark:#25613f;--border:#dfe7e0;--shadow:0 12px 35px rgba(24,49,33,.07);
  --danger:#c84c4c;--warning:#d99032;
}
*{box-sizing:border-box}
body{margin:0;font-family:"DM Sans",sans-serif;background:var(--bg);color:var(--text)}
button,input,select,textarea{font:inherit}
button{cursor:pointer;border:0}
.app{display:flex;min-height:100vh}
.sidebar{width:255px;background:#17231b;color:#fff;padding:25px 16px;display:flex;flex-direction:column;position:fixed;inset:0 auto 0 0}
.brand{display:flex;gap:12px;align-items:center;padding:4px 10px 32px}
.brand-icon{width:42px;height:42px;border-radius:13px;background:#7bc08f;color:#17231b;display:grid;place-items:center;font-size:22px;font-weight:700}
.brand h2{font-family:"Space Grotesk";font-size:19px;margin:0}.brand span{font-size:11px;color:#9baa9f}
nav{display:grid;gap:7px}.nav-link{background:transparent;color:#aebbb2;text-align:left;padding:13px 14px;border-radius:11px;display:flex;gap:12px;align-items:center}
.nav-link:hover,.nav-link.active{background:#2a3a30;color:#fff}.nav-link.active{box-shadow:inset 3px 0 #7bc08f}
.sidebar-bottom{margin-top:auto}.admin-card{display:flex;gap:10px;align-items:center;padding:13px 8px;border-top:1px solid #334039}.avatar,.top-avatar{display:grid;place-items:center;border-radius:50%;background:#d9efdf;color:#27613e;font-weight:700}
.avatar{width:38px;height:38px}.admin-card strong,.admin-card small{display:block}.admin-card small{font-size:11px;color:#98a69d;margin-top:2px}.logout{background:transparent;color:#aebbb2;padding:11px 8px}
.main{margin-left:255px;width:calc(100% - 255px);padding:28px 36px}
.topbar{display:flex;justify-content:space-between;align-items:center;margin-bottom:30px}.eyebrow{color:var(--muted);font-size:12px;margin:0 0 5px}.topbar h1{font-family:"Space Grotesk";margin:0;font-size:29px}.top-actions{display:flex;gap:12px;align-items:center}.icon-btn{width:42px;height:42px;border-radius:12px;background:var(--surface);border:1px solid var(--border);color:var(--text)}.top-avatar{width:42px;height:42px}
.page-section{display:none}.page-section.active{display:block}
.welcome{background:linear-gradient(110deg,#dcefe1,#f5f8ee);border:1px solid #d4e5d7;border-radius:20px;padding:28px;display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}
.welcome h2,.section-head h2{font-family:"Space Grotesk";margin:8px 0 5px;font-size:25px}.welcome p,.section-head p{color:var(--muted);margin:0}.badge{display:inline-block;background:#e4f1e6;color:#347c55;font-size:10px;font-weight:700;letter-spacing:1px;padding:6px 9px;border-radius:20px}
.primary,.secondary{padding:11px 16px;border-radius:10px;font-weight:600}.primary{background:var(--primary);color:#fff}.primary:hover{background:var(--primary-dark)}.secondary{background:var(--surface);border:1px solid var(--border);color:var(--text)}
.stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:17px;margin-bottom:22px}.stat-card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:19px;display:flex;gap:14px;align-items:center;box-shadow:var(--shadow)}.stat-card span,.stat-card small{display:block;color:var(--muted);font-size:12px}.stat-card strong{font-family:"Space Grotesk";display:block;font-size:26px;margin:3px 0}.stat-icon{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;font-size:18px}.green{background:#e1f1e5;color:#347c55}.blue{background:#e2edf7;color:#3976a9}.orange{background:#faeddc;color:#bd7420}.purple{background:#eee6f7;color:#8153a8}
.two-col{display:grid;grid-template-columns:1.25fr 1fr;gap:20px}.panel{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:20px;box-shadow:var(--shadow)}.panel-head{display:flex;justify-content:space-between;margin-bottom:17px}.panel h3{margin:0;font-family:"Space Grotesk"}.panel-head p{color:var(--muted);font-size:12px;margin:4px 0}
.section-head{display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:22px}.filter-row{display:flex;gap:10px;margin-bottom:15px}.search,select,textarea{border:1px solid var(--border);background:var(--surface);color:var(--text);padding:11px 13px;border-radius:10px;outline:none}.search{width:280px}select{min-width:150px}
table{width:100%;border-collapse:collapse}th{text-align:left;font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.5px;padding:13px;border-bottom:1px solid var(--border)}td{padding:14px 13px;border-bottom:1px solid #edf1ed;font-size:13px}tr:last-child td{border-bottom:0}.table-panel{overflow:auto}
.type,.status{display:inline-flex;padding:5px 8px;border-radius:20px;font-size:10px;font-weight:700}.type.income{background:#e4f2e7;color:#337c50}.type.expense{background:#fae7e7;color:#b74a4a}.status.active{background:#e4f2e7;color:#337c50}.status.disabled{background:#eee;color:#777}
.action-btn{padding:7px 9px;border-radius:8px;background:var(--surface2);font-size:11px;margin-right:4px}.action-btn.danger{color:var(--danger)}.action-btn.warning{color:var(--warning)}
.content-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:18px}.content-card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:19px}.content-card .content-type{font-size:10px;color:var(--primary);font-weight:700;text-transform:uppercase}.content-card h3{margin:8px 0}.content-card p{color:var(--muted);line-height:1.6;font-size:13px}.content-actions{border-top:1px solid var(--border);padding-top:13px;margin-top:15px}
.category-bars{display:grid;gap:15px}.bar-row{display:grid;grid-template-columns:110px 1fr 40px;align-items:center;gap:10px;font-size:12px}.bar-track{height:8px;background:#e9eee9;border-radius:20px;overflow:hidden}.bar-fill{height:100%;background:#5a9d70;border-radius:20px}
.activity-item{display:flex;gap:10px;padding:11px 0;border-bottom:1px solid #edf1ed;font-size:12px}.activity-item:last-child{border:0}.activity-dot{width:8px;height:8px;background:#5a9d70;border-radius:50%;margin-top:5px}.activity-item small{display:block;color:var(--muted);margin-top:3px}
.large-stat{display:block}.large-stat strong{font-size:38px;margin:8px 0}.large-stat{min-height:130px}
.donut-wrap{display:flex;align-items:center;gap:30px;min-height:220px}.donut{width:160px;height:160px;border-radius:50%;background:conic-gradient(#5a9d70 0 34%,#e5a35b 34% 100%);display:grid;place-items:center}.donut>div{width:108px;height:108px;border-radius:50%;background:var(--surface);display:grid;place-items:center;align-content:center}.donut strong{font-size:23px}.donut span{font-size:11px;color:var(--muted)}.legend p{font-size:12px}.dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:6px}.dot.income{background:#5a9d70}.dot.expense{background:#e5a35b}.legend b{margin-left:18px}
.toast{position:fixed;right:28px;top:24px;background:#17231b;color:#fff;padding:12px 17px;border-radius:10px;opacity:0;transform:translateY(-10px);transition:.25s;z-index:10}.toast.show{opacity:1;transform:none}
.modal{position:fixed;inset:0;background:rgba(12,22,15,.5);display:none;place-items:center;z-index:20;padding:20px}.modal.show{display:grid}.modal-box{width:min(500px,100%);background:var(--surface);border-radius:18px;padding:25px;position:relative}.modal-box h3{font-family:"Space Grotesk";font-size:22px;margin:0 0 20px}.close{position:absolute;right:17px;top:14px;background:transparent;font-size:25px;color:var(--muted)}.form-group{margin-bottom:15px}.form-group label{display:block;font-size:12px;font-weight:600;margin-bottom:6px}.form-group input,.form-group select,.form-group textarea{width:100%}.form-actions{display:flex;justify-content:flex-end;gap:9px;margin-top:20px}
.dark{--bg:#111713;--surface:#1b241e;--surface2:#263128;--text:#edf5ee;--muted:#9baaa0;--border:#334137;--shadow:none}.dark .welcome{background:#202d24;border-color:#34473a}.dark td,.dark .activity-item{border-color:#2c382f}.dark .donut>div{background:var(--surface)}
@media(max-width:1050px){.stats-grid{grid-template-columns:repeat(2,1fr)}.two-col{grid-template-columns:1fr}.content-grid{grid-template-columns:1fr}}
@media(max-width:760px){.sidebar{width:72px;padding:18px 10px}.brand{justify-content:center;padding-bottom:25px}.brand div:not(.brand-icon),.nav-link span,.admin-card div:not(.avatar),.logout{display:none}.nav-link{justify-content:center}.main{margin-left:72px;width:calc(100% - 72px);padding:20px}.section-head,.welcome{align-items:flex-start;flex-direction:column;gap:16px}.stats-grid{grid-template-columns:1fr}.search{width:100%}.filter-row{flex-direction:column}}</style>
<body>
  <div class="app">
    <aside class="sidebar">
      <div class="brand">
        <div class="brand-icon">₿</div>
        <div>
          <h2>CampusCoin</h2>
          <span>Admin Panel</span>
        </div>
      </div>

      <nav>
        <button class="nav-link active" data-section="overview">⌂ <span>Overview</span></button>
        <button class="nav-link" data-section="categories">▦ <span>Categories</span></button>
        <button class="nav-link" data-section="content">✦ <span>Tips & Announcements</span></button>
        <button class="nav-link" data-section="users">♙ <span>User Accounts</span></button>
        <button class="nav-link" data-section="statistics">◔ <span>Statistics</span></button>
      </nav>

      <div class="sidebar-bottom">
        <div class="admin-card">
          <div class="avatar">A</div>
          <div>
            <strong>Administrator</strong>
            <small>System Admin</small>
          </div>
        </div>
        <button id="logoutBtn" class="logout">↪ Logout</button>
      </div>
    </aside>

    <main class="main">
      <header class="topbar">
        <div>
          <p class="eyebrow">CampusCoin / Administration</p>
          <h1 id="pageTitle">Overview</h1>
        </div>
        <div class="top-actions">
          <button class="icon-btn" id="themeBtn" title="Toggle theme">☾</button>
          <div class="top-avatar">A</div>
        </div>
      </header>

      <div id="toast" class="toast"></div>

      <section id="overview" class="page-section active">
        <div class="welcome">
          <div>
            <span class="badge">CONTROL PANEL</span>
            <h2>Manage CampusCoin from one place.</h2>
            <p>Control categories, system content, student accounts and usage statistics.</p>
          </div>
          <button class="primary" data-go="statistics">View Statistics →</button>
        </div>

        <div class="stats-grid">
          <article class="stat-card">
            <div class="stat-icon green">♙</div>
            <div><span>Active Users</span><strong id="activeUsers">0</strong><small>Currently active</small></div>
          </article>
          <article class="stat-card">
            <div class="stat-icon blue">↕</div>
            <div><span>Total Transactions</span><strong id="totalTransactions">0</strong><small>Income + expenses</small></div>
          </article>
          <article class="stat-card">
            <div class="stat-icon orange">▦</div>
            <div><span>Default Categories</span><strong id="categoryCount">0</strong><small>Available to students</small></div>
          </article>
          <article class="stat-card">
            <div class="stat-icon purple">✦</div>
            <div><span>Published Content</span><strong id="contentCount">0</strong><small>Tips & announcements</small></div>
          </article>
        </div>

        <div class="two-col">
          <article class="panel">
            <div class="panel-head"><div><h3>Most Used Categories</h3><p>Based on sample usage data</p></div></div>
            <div id="topCategories" class="category-bars"></div>
          </article>

          <article class="panel">
            <div class="panel-head"><div><h3>Recent Activity</h3><p>Latest admin actions</p></div></div>
            <div id="activityList" class="activity-list"></div>
          </article>
        </div>
      </section>

      <section id="categories" class="page-section">
        <div class="section-head">
          <div><span class="badge">DEFAULT CATEGORIES</span><h2>Income & Expense Categories</h2><p>These categories are available to all students.</p></div>
          <button class="primary" id="addCategoryBtn">+ Add Category</button>
        </div>
        <div class="filter-row">
          <input id="categorySearch" class="search" placeholder="Search categories...">
          <select id="categoryTypeFilter">
            <option value="all">All Types</option><option value="income">Income</option><option value="expense">Expense</option>
          </select>
        </div>
        <div class="panel table-panel">
          <table>
            <thead><tr><th>Category</th><th>Type</th><th>Status</th><th>Usage</th><th>Actions</th></tr></thead>
            <tbody id="categoryTable"></tbody>
          </table>
        </div>
      </section>

      <section id="content" class="page-section">
        <div class="section-head">
          <div><span class="badge">SYSTEM CONTENT</span><h2>Tips & Announcements</h2><p>Create reusable system-wide content for students.</p></div>
          <button class="primary" id="addContentBtn">+ Add Template</button>
        </div>
        <div id="contentCards" class="content-grid"></div>
      </section>

      <section id="users" class="page-section">
        <div class="section-head">
          <div><span class="badge">USER ACCOUNTS</span><h2>Student Accounts</h2><p>View, disable, or reset student accounts.</p></div>
        </div>
        <div class="filter-row">
          <input id="userSearch" class="search" placeholder="Search by name or email...">
          <select id="userStatusFilter">
            <option value="all">All Statuses</option><option value="active">Active</option><option value="disabled">Disabled</option>
          </select>
        </div>
        <div class="panel table-panel">
          <table>
            <thead><tr><th>Student</th><th>Email</th><th>Transactions</th><th>Joined</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody id="userTable"></tbody>
          </table>
        </div>
      </section>

      <section id="statistics" class="page-section">
        <div class="section-head">
          <div><span class="badge">USAGE STATISTICS</span><h2>System Statistics</h2><p>Monitor active users, transactions and popular categories.</p></div>
          <button class="secondary" id="refreshStats">↻ Refresh Data</button>
        </div>
        <div class="stats-grid">
          <article class="stat-card large-stat"><span>Active Users</span><strong id="statUsers">0</strong><small>Student accounts currently active</small></article>
          <article class="stat-card large-stat"><span>Total Transactions</span><strong id="statTransactions">0</strong><small>Transactions logged in the system</small></article>
        </div>
        <div class="two-col">
          <article class="panel">
            <div class="panel-head"><div><h3>Most Used Categories</h3><p>Category usage across student transactions</p></div></div>
            <div id="statsBars" class="category-bars"></div>
          </article>
          <article class="panel">
            <div class="panel-head"><div><h3>Transaction Overview</h3><p>Sample system distribution</p></div></div>
            <div class="donut-wrap">
              <div class="donut"><div><strong>1,248</strong><span>Total</span></div></div>
              <div class="legend"><p><i class="dot income"></i> Income <b>34%</b></p><p><i class="dot expense"></i> Expenses <b>66%</b></p></div>
            </div>
          </article>
        </div>
      </section>
    </main>
  </div>

  <div id="modal" class="modal">
    <div class="modal-box">
      <button class="close" id="closeModal">×</button>
      <h3 id="modalTitle">Add Category</h3>
      <form id="modalForm"></form>
    </div>
  </div>

  <script>
    const state = {
  categories: [
    {id:1,name:"Allowance",type:"income",usage:180},
    {id:2,name:"Part-time Job",type:"income",usage:96},
    {id:3,name:"Scholarship",type:"income",usage:42},
    {id:4,name:"Gift",type:"income",usage:31},
    {id:5,name:"Other Income",type:"income",usage:18},
    {id:6,name:"Food",type:"expense",usage:320},
    {id:7,name:"Transport",type:"expense",usage:214},
    {id:8,name:"Hostel / Rent",type:"expense",usage:157},
    {id:9,name:"Academics",type:"expense",usage:126},
    {id:10,name:"Subscriptions",type:"expense",usage:74},
    {id:11,name:"Entertainment",type:"expense",usage:96},
    {id:12,name:"Miscellaneous",type:"expense",usage:84}
  ],
  contents: [
    {id:1,type:"Saving Tip",title:"The 24-Hour Rule",text:"Before buying a non-essential item, wait 24 hours. This simple pause can help reduce impulse spending.",status:"Published"},
    {id:2,type:"Announcement",title:"Monthly Report Ready",text:"Your monthly spending report is now available. Review your categories and compare them with your budget goals.",status:"Published"},
    {id:3,type:"Saving Tip",title:"Track Small Expenses",text:"Small daily purchases can add up. Record every expense so your monthly picture stays accurate.",status:"Draft"}
  ],
  users: [
    {id:1,name:"Ayesha Khan",email:"ayesha@example.com",transactions:86,joined:"12 Sep 2026",status:"active"},
    {id:2,name:"Hamza Ali",email:"hamza@example.com",transactions:112,joined:"08 Sep 2026",status:"active"},
    {id:3,name:"Sara Ahmed",email:"sara@example.com",transactions:74,joined:"02 Sep 2026",status:"active"},
    {id:4,name:"Bilal Raza",email:"bilal@example.com",transactions:31,joined:"28 Aug 2026",status:"disabled"},
    {id:5,name:"Hira Noor",email:"hira@example.com",transactions:58,joined:"24 Aug 2026",status:"active"}
  ],
  transactions: 1248,
  activities: [
    ["Category updated","Food category usage changed","Today, 10:32 AM"],
    ["User account reset","Password reset requested for Ayesha Khan","Today, 09:18 AM"],
    ["Announcement published","Monthly Report Ready","Yesterday, 04:41 PM"],
    ["Category added","Miscellaneous added to expense categories","Yesterday, 02:12 PM"]
  ]
};

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

function toast(message){
  const el=$("#toast"); el.textContent=message; el.classList.add("show");
  setTimeout(()=>el.classList.remove("show"),2200);
}
function renderStats(){
  const active=state.users.filter(u=>u.status==="active").length;
  $("#activeUsers").textContent=active;
  $("#statUsers").textContent=active;
  $("#totalTransactions").textContent=state.transactions.toLocaleString();
  $("#statTransactions").textContent=state.transactions.toLocaleString();
  $("#categoryCount").textContent=state.categories.length;
  $("#contentCount").textContent=state.contents.filter(c=>c.status==="Published").length;
  renderBars("#topCategories"); renderBars("#statsBars");
}
function renderBars(selector){
  const el=$(selector); if(!el)return;
  const top=[...state.categories].sort((a,b)=>b.usage-a.usage).slice(0,6);
  const max=top[0]?.usage||1;
  el.innerHTML=top.map(c=>`<div class="bar-row"><span>${c.name}</span><div class="bar-track"><div class="bar-fill" style="width:${(c.usage/max)*100}%"></div></div><b>${c.usage}</b></div>`).join("");
}
function renderCategories(){
  const q=$("#categorySearch").value.toLowerCase(), type=$("#categoryTypeFilter").value;
  const list=state.categories.filter(c=>(c.name.toLowerCase().includes(q))&&(type==="all"||c.type===type));
  $("#categoryTable").innerHTML=list.map(c=>`
    <tr><td><strong>${c.name}</strong></td><td><span class="type ${c.type}">${c.type}</span></td>
    <td><span class="status active">Default</span></td><td>${c.usage}</td>
    <td><button class="action-btn" onclick="editCategory(${c.id})">Edit</button><button class="action-btn danger" onclick="deleteCategory(${c.id})">Remove</button></td></tr>`).join("");
}
function renderContents(){
  $("#contentCards").innerHTML=state.contents.map(c=>`
    <article class="content-card"><span class="content-type">${c.type}</span><h3>${c.title}</h3><p>${c.text}</p>
    <div><span class="status ${c.status==="Published"?"active":"disabled"}">${c.status}</span></div>
    <div class="content-actions"><button class="action-btn" onclick="editContent(${c.id})">Edit</button>
    <button class="action-btn danger" onclick="deleteContent(${c.id})">Remove</button></div></article>`).join("");
}
function renderUsers(){
  const q=$("#userSearch").value.toLowerCase(), status=$("#userStatusFilter").value;
  const list=state.users.filter(u=>(u.name.toLowerCase().includes(q)||u.email.toLowerCase().includes(q))&&(status==="all"||u.status===status));
  $("#userTable").innerHTML=list.map(u=>`
    <tr><td><strong>${u.name}</strong></td><td>${u.email}</td><td>${u.transactions}</td><td>${u.joined}</td>
    <td><span class="status ${u.status}">${u.status}</span></td><td>
    <button class="action-btn warning" onclick="toggleUser(${u.id})">${u.status==="active"?"Disable":"Enable"}</button>
    <button class="action-btn" onclick="resetUser(${u.id})">Reset</button></td></tr>`).join("");
}
function renderActivity(){
  $("#activityList").innerHTML=state.activities.map(a=>`<div class="activity-item"><i class="activity-dot"></i><div><strong>${a[0]}</strong><small>${a[1]} · ${a[2]}</small></div></div>`).join("");
}
function openModal(title, html, submit){
  $("#modalTitle").textContent=title;
  $("#modalForm").innerHTML=html+`<div class="form-actions"><button type="button" class="secondary" id="cancelModal">Cancel</button><button class="primary" type="submit">Save</button></div>`;
  $("#modal").classList.add("show");
  $("#cancelModal").onclick=closeModal;
  $("#modalForm").onsubmit=e=>{e.preventDefault();submit(new FormData(e.target));closeModal();}
}
function closeModal(){$("#modal").classList.remove("show")}
function editCategory(id){
  const c=state.categories.find(x=>x.id===id);
  openModal("Edit Category",`<div class="form-group"><label>Category Name</label><input name="name" value="${c.name}" required></div>
  <div class="form-group"><label>Category Type</label><select name="type"><option value="income" ${c.type==="income"?"selected":""}>Income</option><option value="expense" ${c.type==="expense"?"selected":""}>Expense</option></select></div>`,
  f=>{c.name=f.get("name");c.type=f.get("type");renderAll();toast("Category updated.");});
}
function addCategory(){
  openModal("Add Default Category",`<div class="form-group"><label>Category Name</label><input name="name" placeholder="e.g. Books" required></div>
  <div class="form-group"><label>Category Type</label><select name="type"><option value="income">Income</option><option value="expense">Expense</option></select></div>`,
  f=>{state.categories.push({id:Date.now(),name:f.get("name"),type:f.get("type"),usage:0});renderAll();toast("Category added.");});
}
function deleteCategory(id){if(confirm("Remove this default category?")){state.categories=state.categories.filter(c=>c.id!==id);renderAll();toast("Category removed.");}}
function editContent(id){
  const c=state.contents.find(x=>x.id===id);
  openModal("Edit Content Template",`<div class="form-group"><label>Content Type</label><select name="type"><option ${c.type==="Saving Tip"?"selected":""}>Saving Tip</option><option ${c.type==="Announcement"?"selected":""}>Announcement</option></select></div>
  <div class="form-group"><label>Title</label><input name="title" value="${c.title}" required></div>
  <div class="form-group"><label>Message</label><textarea name="text" rows="4" required>${c.text}</textarea></div>`,
  f=>{c.type=f.get("type");c.title=f.get("title");c.text=f.get("text");renderContents();renderStats();toast("Template updated.");});
}
function addContent(){
  openModal("Add Content Template",`<div class="form-group"><label>Content Type</label><select name="type"><option>Saving Tip</option><option>Announcement</option></select></div>
  <div class="form-group"><label>Title</label><input name="title" placeholder="Template title" required></div>
  <div class="form-group"><label>Message</label><textarea name="text" rows="4" placeholder="Write the student-facing message..." required></textarea></div>`,
  f=>{state.contents.push({id:Date.now(),type:f.get("type"),title:f.get("title"),text:f.get("text"),status:"Draft"});renderAll();toast("Template created as draft.");});
}
function deleteContent(id){if(confirm("Remove this content template?")){state.contents=state.contents.filter(c=>c.id!==id);renderAll();toast("Template removed.");}}
function toggleUser(id){const u=state.users.find(x=>x.id===id);u.status=u.status==="active"?"disabled":"active";renderAll();toast(`Account ${u.status}.`);}
function resetUser(id){const u=state.users.find(x=>x.id===id);if(confirm(`Reset password for ${u.name}?`)){toast(`Password reset link generated for ${u.email}.`);}}
function renderAll(){renderStats();renderCategories();renderContents();renderUsers();renderActivity();}
function navigate(section){
  $$(".page-section").forEach(s=>s.classList.toggle("active",s.id===section));
  $$(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.section===section));
  const titles={overview:"Overview",categories:"Categories","content":"Tips & Announcements",users:"User Accounts",statistics:"Statistics"};
  $("#pageTitle").textContent=titles[section]||"Overview";
}
$$(".nav-link").forEach(btn=>btn.onclick=()=>navigate(btn.dataset.section));
$$("[data-go]").forEach(btn=>btn.onclick=()=>navigate(btn.dataset.go));
$("#addCategoryBtn").onclick=addCategory; $("#addContentBtn").onclick=addContent; $("#closeModal").onclick=closeModal;
$("#categorySearch").oninput=renderCategories; $("#categoryTypeFilter").onchange=renderCategories;
$("#userSearch").oninput=renderUsers; $("#userStatusFilter").onchange=renderUsers;
$("#refreshStats").onclick=()=>{renderStats();toast("Statistics refreshed.");};
$("#themeBtn").onclick=()=>document.body.classList.toggle("dark");
$("#logoutBtn").onclick=()=>toast("Logout action connected to your backend here.");
$("#modal").onclick=e=>{if(e.target.id==="modal")closeModal()};
renderAll();
  </script>
</body>
</html>