<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CampusCoin | Reports & Insights</title>
    <link rel="stylesheet" href="categories.css">
</head>
<body>

<div class="app">

    <aside class="sidebar" id="sidebar">
        <div class="logo-area">
            <div class="logo">
                <div class="logo-icon">C</div>
                <div class="logo-text">
                    <h2>CampusCoin</h2>
                    <span>Student Finance</span>
                </div>
            </div>
        </div>

        <div class="nav-title">Main Menu</div>

        <nav class="nav-menu">
            <a href="dashboard.html" class="nav-link"><span class="nav-icon">⌂</span>Dashboard</a>
            <a href="income-expenses.html" class="nav-link"><span class="nav-icon">↕</span>Income & Expenses</a>
            <a href="categories.html" class="nav-link"><span class="nav-icon">▦</span>Categories</a>
            <a href="budget-goals.html" class="nav-link"><span class="nav-icon">◈</span>Budget Goals</a>
            <a href="reports-insights.html" class="nav-link"><span class="nav-icon">▥</span>Reports & Insights</a>
            <a href="saving-tips.html" class="nav-link"><span class="nav-icon">★</span>Saving Tips</a>
        </nav>

        <div class="sidebar-bottom">
            <nav class="nav-menu">
                <a href="profile.html" class="nav-link"><span class="nav-icon">◯</span>Profile</a>
                <a href="dashboard.html" class="nav-link"><span class="nav-icon">↪</span>Logout</a>
            </nav>
        </div>
    </aside>

    <main class="main">

        <header class="topbar">
            <button class="menu-btn" id="menuButton">☰</button>

            <div class="topbar-right">
                <button class="theme-btn" id="themeButton">☾</button>
                <div class="user-mini">
                    <div class="avatar">H</div>
                    <span>Student</span>
                </div>
            </div>
        </header>

        <section class="content">

            <div class="page-heading">
                <h1>Reports & Insights</h1>
                <p>Understand your spending habits and financial progress.</p>
            </div>

            <div class="report-grid">

                <div class="card">
                    <div class="card-header">
                        <h2>Financial Summary</h2>
                    </div>

                    <div class="report-item">
                        <span>Total Income</span>
                        <strong class="income">₨45,000</strong>
                    </div>

                    <div class="report-item">
                        <span>Total Expenses</span>
                        <strong class="expense">₨28,450</strong>
                    </div>

                    <div class="report-item">
                        <span>Net Balance</span>
                        <strong>₨16,550</strong>
                    </div>

                    <div class="report-item">
                        <span>Savings Rate</span>
                        <strong>36.7%</strong>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h2>Top Spending Categories</h2>
                    </div>

                    <div class="report-item">
                        <span>Food</span>
                        <strong>₨8,500</strong>
                    </div>

                    <div class="report-item">
                        <span>Education</span>
                        <strong>₨5,500</strong>
                    </div>

                    <div class="report-item">
                        <span>Transport</span>
                        <strong>₨4,200</strong>
                    </div>

                    <div class="report-item">
                        <span>Entertainment</span>
                        <strong>₨3,250</strong>
                    </div>
                </div>

            </div>

            <div class="card" style="margin-top:20px;">
                <div class="card-header">
                    <h2>Monthly Spending Overview</h2>
                </div>

                <div class="chart">
                    <div class="bar-wrapper">
                        <div class="bar" style="height:40%"></div>
                        <span>Jan</span>
                    </div>

                    <div class="bar-wrapper">
                        <div class="bar" style="height:55%"></div>
                        <span>Feb</span>
                    </div>

                    <div class="bar-wrapper">
                        <div class="bar" style="height:48%"></div>
                        <span>Mar</span>
                    </div>

                    <div class="bar-wrapper">
                        <div class="bar" style="height:70%"></div>
                        <span>Apr</span>
                    </div>

                    <div class="bar-wrapper">
                        <div class="bar" style="height:58%"></div>
                        <span>May</span>
                    </div>

                    <div class="bar-wrapper">
                        <div class="bar" style="height:65%"></div>
                        <span>Jun</span>
                    </div>

                    <div class="bar-wrapper">
                        <div class="bar" style="height:52%"></div>
                        <span>Jul</span>
                    </div>
                </div>
            </div>

        </section>
    </main>
</div>

<script src="script.js"></script>
</body>
</html>