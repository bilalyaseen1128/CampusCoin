<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CampusCoin | Saving Tips</title>
    <link rel="stylesheet" href="categories.css">
</head>
<body>

<div class="app">

    <aside class="sidebar" id="sidebar">
        <div class="logo-area">
            <div class="logo">
                <div class="logo-icon">C</div>
                <div class="logo-text">
                    <h2>CampusCoin</h2>
                    <span>Student Finance</span>
                </div>
            </div>
        </div>

        <div class="nav-title">Main Menu</div>

        <nav class="nav-menu">
            <a href="dashboard.html" class="nav-link"><span class="nav-icon">⌂</span>Dashboard</a>
            <a href="income-expenses.html" class="nav-link"><span class="nav-icon">↕</span>Income & Expenses</a>
            <a href="categories.html" class="nav-link"><span class="nav-icon">▦</span>Categories</a>
            <a href="budget-goals.html" class="nav-link"><span class="nav-icon">◈</span>Budget Goals</a>
            <a href="reports-insights.html" class="nav-link"><span class="nav-icon">▥</span>Reports & Insights</a>
            <a href="saving-tips.html" class="nav-link"><span class="nav-icon">★</span>Saving Tips</a>
        </nav>

        <div class="sidebar-bottom">
            <nav class="nav-menu">
                <a href="profile.html" class="nav-link"><span class="nav-icon">◯</span>Profile</a>
                <a href="dashboard.html" class="nav-link"><span class="nav-icon">↪</span>Logout</a>
            </nav>
        </div>
    </aside>

    <main class="main">

        <header class="topbar">
            <button class="menu-btn" id="menuButton">☰</button>

            <div class="topbar-right">
                <button class="theme-btn" id="themeButton">☾</button>

                <div class="user-mini">
                    <div class="avatar">H</div>
                    <span>Student</span>
                </div>
            </div>
        </header>

        <section class="content">

            <div class="page-heading">
                <h1>Saving Tips</h1>
                <p>Simple financial habits that can help students manage money.</p>
            </div>

            <div class="tips-grid">

                <div class="tip-card">
                    <div class="tip-icon">💰</div>
                    <h3>Track Every Expense</h3>
                    <p>Record your daily spending so you can understand where your money goes.</p>
                </div>

                <div class="tip-card">
                    <div class="tip-icon">🍱</div>
                    <h3>Plan Your Meals</h3>
                    <p>Planning meals ahead can help reduce unnecessary food spending.</p>
                </div>

                <div class="tip-card">
                    <div class="tip-icon">📝</div>
                    <h3>Create a Budget</h3>
                    <p>Set a monthly spending limit for important categories before the month begins.</p>
                </div>

                <div class="tip-card">
                    <div class="tip-icon">🎯</div>
                    <h3>Set Savings Goals</h3>
                    <p>Choose a realistic savings target and make regular contributions toward it.</p>
                </div>

                <div class="tip-card">
                    <div class="tip-icon">🛍️</div>
                    <h3>Avoid Impulse Buying</h3>
                    <p>Give yourself time to think before making unnecessary purchases.</p>
                </div>

                <div class="tip-card">
                    <div class="tip-icon">📊</div>
                    <h3>Review Your Spending</h3>
                    <p>Check your reports regularly to identify spending patterns and adjust your budget.</p>
                </div>

            </div>

        </section>
    </main>
</div>

<script src="script.js"></script>
</body>
</html>