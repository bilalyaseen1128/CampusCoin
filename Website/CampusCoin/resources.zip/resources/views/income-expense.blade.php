<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CampusCoin | Income & Expenses</title>
    <link rel="stylesheet" href="categories.css">
</head>
<body>

<div class="app">

    <aside class="sidebar" id="sidebar">
        <div class="logo-area">
            <div class="logo">
                <div class="logo-icon">C</div>
                <div class="logo-text">
                    <h2>CampusCoin</h2>
                    <span>Student Finance</span>
                </div>
            </div>
        </div>

        <div class="nav-title">Main Menu</div>

        <nav class="nav-menu">
            <a href="dashboard.html" class="nav-link"><span class="nav-icon">⌂</span>Dashboard</a>
            <a href="income-expenses.html" class="nav-link"><span class="nav-icon">↕</span>Income & Expenses</a>
            <a href="categories.html" class="nav-link"><span class="nav-icon">▦</span>Categories</a>
            <a href="budget-goals.html" class="nav-link"><span class="nav-icon">◈</span>Budget Goals</a>
            <a href="reports-insights.html" class="nav-link"><span class="nav-icon">▥</span>Reports & Insights</a>
            <a href="saving-tips.html" class="nav-link"><span class="nav-icon">★</span>Saving Tips</a>
        </nav>

        <div class="sidebar-bottom">
            <nav class="nav-menu">
                <a href="profile.html" class="nav-link"><span class="nav-icon">◯</span>Profile</a>
                <a href="dashboard.html" class="nav-link" onclick="return confirm('Are you sure you want to logout?')"><span class="nav-icon">↪</span>Logout</a>
            </nav>
        </div>
    </aside>

    <main class="main">

        <header class="topbar">
            <button class="menu-btn" id="menuButton">☰</button>

            <div class="topbar-right">
                <button class="theme-btn" id="themeButton">☾</button>
                <div class="user-mini">
                    <div class="avatar">H</div>
                    <span>Student</span>
                </div>
            </div>
        </header>

        <section class="content">

            <div class="page-heading">
                <h1>Income & Expenses</h1>
                <p>Manage and keep track of your money.</p>
            </div>

            <div class="stats-grid">

                <div class="stat-card">
                    <div class="stat-top">
                        <span class="stat-icon">↑</span>
                        <span class="stat-change income">Income</span>
                    </div>
                    <h3>₨45,000</h3>
                    <p>This Month</p>
                </div>

                <div class="stat-card">
                    <div class="stat-top">
                        <span class="stat-icon">↓</span>
                        <span class="stat-change expense">Expenses</span>
                    </div>
                    <h3>₨28,450</h3>
                    <p>This Month</p>
                </div>

                <div class="stat-card">
                    <div class="stat-top">
                        <span class="stat-icon">₨</span>
                    </div>
                    <h3>₨16,550</h3>
                    <p>Net Balance</p>
                </div>

                <div class="stat-card">
                    <div class="stat-top">
                        <span class="stat-icon">%</span>
                    </div>
                    <h3>63.2%</h3>
                    <p>Expense Ratio</p>
                </div>

            </div>

            <div class="page-actions">
                <button class="btn btn-secondary">Filter</button>
                <button class="btn btn-primary">+ Add Transaction</button>
            </div>

            <div class="card">
                <div class="card-header">
                    <h2>Transaction History</h2>
                </div>

                <div class="table-wrapper">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Description</th>
                                <th>Category</th>
                                <th>Date</th>
                                <th>Type</th>
                                <th>Amount</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td>Monthly Allowance</td>
                                <td>Allowance</td>
                                <td>20 Sep 2026</td>
                                <td><span class="badge badge-income">Income</span></td>
                                <td class="income">+₨10,000</td>
                                <td><button class="btn btn-danger">Delete</button></td>
                            </tr>

                            <tr>
                                <td>University Books</td>
                                <td>Education</td>
                                <td>19 Sep 2026</td>
                                <td><span class="badge badge-expense">Expense</span></td>
                                <td class="expense">-₨1,500</td>
                                <td><button class="btn btn-danger">Delete</button></td>
                            </tr>

                            <tr>
                                <td>Lunch</td>
                                <td>Food</td>
                                <td>18 Sep 2026</td>
                                <td><span class="badge badge-expense">Expense</span></td>
                                <td class="expense">-₨850</td>
                                <td><button class="btn btn-danger">Delete</button></td>
                            </tr>

                            <tr>
                                <td>Part-time Job</td>
                                <td>Job</td>
                                <td>15 Sep 2026</td>
                                <td><span class="badge badge-income">Income</span></td>
                                <td class="income">+₨15,000</td>
                                <td><button class="btn btn-danger">Delete</button></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

        </section>
    </main>
</div>

<script src="script.js"></script>
</body>
</html>