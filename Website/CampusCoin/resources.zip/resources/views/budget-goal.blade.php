<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campus Coin - Budget Goals & Alerts</title>
    <link rel="stylesheet" href="style.css">
</head>
<style>• (css)                                                                                                 :root {
    --navy-950: #071827;
    --navy-900: #0b2235;
    --navy-800: #12334a;
    --navy-700: #1b4862;
    --mint-600: #18b7a4;
    --mint-500: #2dd4bf;
    --mint-400: #5eead4;
    --mint-100: #dffaf5;
    --page: #edf4f5;
    --page-alt: #e6f0f2;
    --card: #ffffff;
    --text: #102a43;
    --muted: #63798b;
    --border: #d3e1e5;
    --warning: #d79822;
    --warning-bg: #fff3d8;
    --danger: #d84c64;
    --danger-bg: #ffe5ea;
    --shadow: 0 14px 34px rgba(7, 24, 39, 0.07);
    --shadow-soft: 0 7px 20px rgba(7, 24, 39, 0.05);
}

body.dark {
    --page: #071827;
    --page-alt: #0a1f31;
    --card: #0d2639;
    --text: #e9f4f5;
    --muted: #9cb1bd;
    --border: #204256;
    --mint-100: #123c39;
    --warning-bg: #443616;
    --danger-bg: #47222b;
    --shadow: 0 18px 42px rgba(0, 0, 0, 0.24);
    --shadow-soft: 0 8px 22px rgba(0, 0, 0, 0.2);
}

* {
    box-sizing: border-box;
}

html {
    scroll-behavior: smooth;
}

body {
    margin: 0;
    background: var(--page);
    color: var(--text);
    font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    line-height: 1.5;
    overflow-x: hidden;
}

button,
input,
select {
    font: inherit;
}

button {
    cursor: pointer;
}

a {
    color: inherit;
    text-decoration: none;
}

.container {
    width: min(1120px, calc(100% - 40px));
    margin: 0 auto;
}

/* Header */

.site-header {
    position: sticky;
    top: 0;
    z-index: 50;
    background: rgba(255, 255, 255, 0.94);
    border-bottom: 1px solid var(--border);
    backdrop-filter: blur(14px);
}

.dark .site-header {
    background: rgba(7, 24, 39, 0.94);
}

.header-inner {
    min-height: 72px;
    display: flex;
    align-items: center;
    gap: 28px;
}

.brand {
    color: var(--navy-800);
    font-size: 1.27rem;
    font-weight: 850;
    letter-spacing: -0.025em;
}

.dark .brand {
    color: var(--mint-400);
}

.main-nav {
    display: flex;
    align-items: center;
    gap: 22px;
    margin-left: auto;
}

.main-nav a {
    color: var(--muted);
    font-size: 0.9rem;
    font-weight: 700;
}

.main-nav a:hover {
    color: var(--mint-600);
}

.theme-btn {
    min-width: 76px;
    border: 1px solid var(--border);
    border-radius: 9px;
    padding: 9px 12px;
    background: var(--card);
    color: var(--text);
    font-weight: 750;
}

.theme-btn:hover {
    border-color: var(--mint-500);
}

/* Hero */

.hero {
    background: linear-gradient(135deg, var(--navy-950), var(--navy-800));
    color: #ffffff;
    padding: 76px 0 72px;
}

.hero-inner {
    display: flex;
    align-items: end;
    justify-content: space-between;
    gap: 40px;
}

.hero-copy {
    max-width: 720px;
}

.eyebrow {
    margin: 0 0 7px;
    color: var(--mint-600);
    font-size: 0.73rem;
    font-weight: 850;
    letter-spacing: 0.14em;
    text-transform: uppercase;
}

.hero .eyebrow {
    color: var(--mint-400);
}

h1,
h2,
h3,
p {
    margin-top: 0;
}

h1 {
    margin-bottom: 14px;
    font-size: clamp(2.35rem, 5vw, 4rem);
    line-height: 1.02;
    letter-spacing: -0.045em;
}

h2 {
    margin-bottom: 0;
    font-size: clamp(1.45rem, 2.5vw, 1.9rem);
    line-height: 1.2;
    letter-spacing: -0.03em;
}

h3 {
    margin-bottom: 6px;
}

.hero-copy > p:last-child {
    max-width: 650px;
    margin-bottom: 0;
    color: #cbd9e0;
}

/* Buttons */

.primary-btn,
.secondary-btn {
    min-height: 45px;
    border-radius: 9px;
    padding: 10px 17px;
    font-weight: 800;
    transition: transform 0.2s ease, background 0.2s ease, border-color 0.2s ease;
}

.primary-btn {
    border: 1px solid var(--mint-500);
    background: var(--mint-500);
    color: var(--navy-950);
}

.primary-btn:hover {
    background: var(--mint-400);
    transform: translateY(-1px);
}

.secondary-btn {
    border: 1px solid var(--border);
    background: var(--card);
    color: var(--text);
}

.secondary-btn:hover {
    border-color: var(--mint-500);
    transform: translateY(-1px);
}

.hero-btn {
    min-width: 160px;
}

/* Sections */

.summary-section,
.setup-section,
.budgets-section,
.alerts-section {
    padding: 60px 0;
}

.section-heading {
    display: flex;
    align-items: end;
    justify-content: space-between;
    gap: 25px;
    margin-bottom: 25px;
}

.section-note,
.section-description {
    color: var(--muted);
    font-size: 0.88rem;
}

.section-note {
    margin: 0;
}

.section-description {
    margin: 8px 0 0;
    max-width: 680px;
}

/* Summary */

.summary-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.summary-card {
    display: flex;
    gap: 13px;
    align-items: flex-start;
    padding: 20px;
    border: 1px solid var(--border);
    border-radius: 15px;
    background: var(--card);
    box-shadow: var(--shadow-soft);
}

.summary-icon {
    width: 39px;
    height: 39px;
    flex: 0 0 39px;
    display: grid;
    place-items: center;
    border-radius: 10px;
    background: var(--mint-100);
    color: var(--navy-800);
    font-weight: 900;
}

.dark .summary-icon {
    color: var(--mint-400);
}

.summary-card span,
.summary-card small {
    display: block;
}

.summary-card span {
    color: var(--muted);
    font-size: 0.77rem;
    font-weight: 700;
}

.summary-card strong {
    display: block;
    margin: 3px 0 2px;
    color: var(--text);
    font-size: 1.5rem;
}

.summary-card small {
    color: var(--muted);
    font-size: 0.7rem;
}

/* Overview */

.overview-panel {
    display: grid;
    grid-template-columns: 1fr 310px;
    gap: 30px;
    margin-top: 18px;
    padding: 25px;
    border: 1px solid var(--border);
    border-radius: 16px;
    background: var(--card);
    box-shadow: var(--shadow-soft);
}

.panel-heading {
    display: flex;
    justify-content: space-between;
    align-items: end;
    gap: 20px;
    margin-bottom: 18px;
}

.panel-heading h3 {
    margin: 0;
}

.panel-heading > strong {
    color: var(--mint-600);
    font-size: 1.25rem;
}

.progress-track {
    width: 100%;
    height: 9px;
    overflow: hidden;
    border-radius: 999px;
    background: color-mix(in srgb, var(--border) 80%, transparent);
}

.progress-track.large {
    height: 11px;
}

.progress-fill {
    width: 0;
    height: 100%;
    border-radius: inherit;
    background: var(--mint-500);
    transition: width 0.3s ease;
}

.progress-fill.warning {
    background: var(--warning);
}

.progress-fill.exceeded {
    background: var(--danger);
}

.overview-details {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
}

.overview-details div {
    padding: 12px;
    border: 1px solid var(--border);
    border-radius: 10px;
}

.overview-details span {
    display: block;
    color: var(--muted);
    font-size: 0.72rem;
}

.overview-details strong {
    display: block;
    margin-top: 4px;
    font-size: 0.98rem;
}

/* Setup */

.setup-section {
    background: var(--page-alt);
    border-top: 1px solid var(--border);
    border-bottom: 1px solid var(--border);
}

.budget-form {
    display: grid;
    grid-template-columns: 1fr 1fr auto;
    align-items: end;
    gap: 18px;
    padding: 25px;
    border: 1px solid var(--border);
    border-radius: 16px;
    background: var(--card);
    box-shadow: var(--shadow);
}

.field {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.field label {
    color: var(--text);
    font-size: 0.84rem;
    font-weight: 800;
}

.field input,
.field select {
    width: 100%;
    min-height: 46px;
    border: 1px solid var(--border);
    border-radius: 9px;
    padding: 10px 12px;
    outline: none;
    background: var(--card);
    color: var(--text);
}

.field input:focus,
.field select:focus {
    border-color: var(--mint-500);
    box-shadow: 0 0 0 3px rgba(45, 212, 191, 0.14);
}

.money-input {
    display: flex;
    align-items: center;
    min-height: 46px;
    overflow: hidden;
    border: 1px solid var(--border);
    border-radius: 9px;
    background: var(--card);
}

.money-input span {
    padding: 0 11px;
    color: var(--muted);
    font-weight: 800;
}

.money-input input {
    min-height: 44px;
    border: 0;
    border-left: 1px solid var(--border);
    border-radius: 0;
}

.money-input input:focus {
    box-shadow: none;
}

.form-message {
    min-height: 20px;
    margin: 10px 0 0;
    color: var(--danger);
    font-size: 0.83rem;
    font-weight: 700;
}

/* Budget Cards */

.budgets-section {
    background: var(--page);
}

.budget-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 18px;
}

.budget-card {
    padding: 24px;
    border: 1px solid var(--border);
    border-radius: 16px;
    background: var(--card);
    box-shadow: var(--shadow);
}

.budget-card-header {
    display: flex;
    justify-content: space-between;
    align-items: start;
    gap: 15px;
}

.category-name {
    margin-bottom: 3px;
    font-size: 1.22rem;
}

.budget-limit {
    color: var(--muted);
    font-size: 0.81rem;
}

.status-badge {
    border-radius: 999px;
    padding: 5px 10px;
    background: var(--mint-100);
    color: var(--navy-800);
    font-size: 0.7rem;
    font-weight: 850;
    white-space: nowrap;
}

.dark .status-badge {
    color: var(--mint-400);
}

.status-badge.warning {
    background: var(--warning-bg);
    color: #8b5c0b;
}

.dark .status-badge.warning {
    color: #f4c96b;
}

.status-badge.exceeded {
    background: var(--danger-bg);
    color: #a52e43;
}

.dark .status-badge.exceeded {
    color: #ff91a3;
}

.stats-row {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 12px;
    margin: 22px 0 19px;
}

.stat {
    padding: 14px;
    border: 1px solid var(--border);
    border-radius: 10px;
    background: color-mix(in srgb, var(--page) 35%, var(--card));
}

.stat span {
    display: block;
    color: var(--muted);
    font-size: 0.73rem;
    margin-bottom: 4px;
}

.stat strong {
    font-size: 1.03rem;
}

.progress-label {
    display: flex;
    justify-content: space-between;
    gap: 10px;
    margin-bottom: 8px;
    color: var(--muted);
    font-size: 0.76rem;
    font-weight: 750;
}

.spending-form {
    display: flex;
    gap: 9px;
    margin-top: 20px;
}

.spending-form input {
    min-width: 0;
    flex: 1;
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 9px 10px;
    outline: none;
    background: var(--card);
    color: var(--text);
}

.spending-form input:focus {
    border-color: var(--mint-500);
}

.small-btn {
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 9px 12px;
    background: var(--card);
    color: var(--text);
    font-weight: 750;
}

.small-btn:hover {
    border-color: var(--mint-500);
}

.card-actions {
    display: flex;
    gap: 8px;
    margin-top: 10px;
}

.card-actions .small-btn {
    flex: 1;
}

.delete-btn:hover {
    color: var(--danger);
    border-color: var(--danger);
}

.count-label {
    color: var(--muted);
    font-size: 0.84rem;
    font-weight: 750;
}

/* Empty States */

.empty-state,
.empty-alerts {
    padding: 44px;
    border: 1px solid var(--border);
    border-radius: 16px;
    background: var(--card);
    box-shadow: var(--shadow-soft);
    text-align: center;
}

.empty-state {
    display: none;
}

.empty-icon,
.check-icon {
    width: 48px;
    height: 48px;
    display: grid;
    place-items: center;
    margin: 0 auto 13px;
    border-radius: 13px;
    background: var(--mint-100);
    color: var(--mint-600);
    font-size: 1.35rem;
    font-weight: 900;
}

.empty-state p,
.empty-alerts p {
    color: var(--muted);
}

/* Alerts */

.alerts-section {
    background: var(--page-alt);
    border-top: 1px solid var(--border);
}

.alert-info-strip {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 20px;
    margin-bottom: 16px;
    padding: 15px 17px;
    border: 1px solid var(--border);
    border-radius: 12px;
    background: var(--card);
}

.alert-info-strip strong,
.alert-info-strip span {
    display: block;
}

.alert-info-strip span {
    color: var(--muted);
    font-size: 0.79rem;
}

.alert-status {
    padding: 5px 9px;
    border-radius: 999px;
    background: var(--mint-100);
    color: var(--mint-600) !important;
    font-weight: 800;
    white-space: nowrap;
}

.alert-list {
    display: grid;
    gap: 12px;
}

.alert-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 18px;
    padding: 17px 18px;
    border: 1px solid var(--border);
    border-left: 4px solid var(--mint-500);
    border-radius: 13px;
    background: var(--card);
    box-shadow: var(--shadow-soft);
}

.alert-item.warning {
    border-left-color: var(--warning);
}

.alert-item.exceeded {
    border-left-color: var(--danger);
}

.alert-copy strong {
    display: block;
    margin-bottom: 2px;
}

.alert-copy span {
    color: var(--muted);
    font-size: 0.84rem;
}

.dismiss-btn {
    border: 0;
    background: transparent;
    color: var(--muted);
    font-weight: 750;
    white-space: nowrap;
}

.dismiss-btn:hover {
    color: var(--text);
}

.danger-outline {
    color: var(--danger);
}

/* Footer */

.site-footer {
    padding: 31px 0 18px;
    background: var(--navy-950);
    color: #ffffff;
}

.footer-inner {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 25px;
}

.footer-brand {
    color: var(--mint-400);
    font-size: 1.1rem;
}

.site-footer p {
    margin: 3px 0 0;
    color: #9fb1bc;
    font-size: 0.82rem;
}

.footer-links {
    display: flex;
    flex-wrap: wrap;
    gap: 19px;
}

.footer-links a {
    color: #c6d5dc;
    font-size: 0.83rem;
    font-weight: 700;
}

.footer-links a:hover {
    color: var(--mint-400);
}

.footer-bottom {
    display: flex;
    justify-content: space-between;
    gap: 20px;
    margin-top: 22px;
    padding-top: 15px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    color: #8297a4;
    font-size: 0.73rem;
}

/* Modal */

.modal-backdrop {
    position: fixed;
    inset: 0;
    z-index: 100;
    display: none;
    align-items: center;
    justify-content: center;
    padding: 20px;
    background: rgba(3, 14, 24, 0.72);
}

.modal-backdrop.open {
    display: flex;
}

.modal {
    width: min(500px, 100%);
    max-height: calc(100vh - 40px);
    overflow: auto;
    padding: 25px;
    border: 1px solid var(--border);
    border-radius: 17px;
    background: var(--card);
    box-shadow: 0 25px 70px rgba(0, 0, 0, 0.25);
}

.modal-header {
    display: flex;
    align-items: start;
    justify-content: space-between;
    gap: 15px;
    margin-bottom: 22px;
}

.modal-header h2 {
    margin-bottom: 5px;
}

.modal-header p:last-child {
    margin: 0;
    color: var(--muted);
    font-size: 0.82rem;
}

.close-btn {
    width: 38px;
    height: 38px;
    border: 1px solid var(--border);
    border-radius: 9px;
    background: var(--card);
    color: var(--text);
    font-size: 1.5rem;
    line-height: 1;
}

.close-btn:hover {
    border-color: var(--mint-500);
}

.modal-actions {
    display: flex;
    justify-content: flex-end;
    gap: 9px;
    margin-top: 7px;
}

/* Light Mode Card Blur Outline */

body:not(.dark) .summary-card,
body:not(.dark) .overview-panel,
body:not(.dark) .budget-form,
body:not(.dark) .budget-card,
body:not(.dark) .alert-item,
body:not(.dark) .empty-state,
body:not(.dark) .empty-alerts {
    border-color: rgba(45, 212, 191, 0.22);
    box-shadow:
        0 0 0 1px rgba(45, 212, 191, 0.08),
        0 10px 30px rgba(7, 24, 39, 0.08);
    backdrop-filter: blur(8px);
}

/* Responsive */

@media (max-width: 950px) {
    .summary-grid {
        grid-template-columns: repeat(2, 1fr);
    }

    .overview-panel {
        grid-template-columns: 1fr;
    }

    .budget-form {
        grid-template-columns: 1fr 1fr;
    }

    .form-btn {
        grid-column: 1 / -1;
    }
}

@media (max-width: 760px) {
    .container {
        width: min(100% - 28px, 1120px);
    }

    .header-inner {
        min-height: 64px;
        gap: 12px;
    }

    .main-nav {
        gap: 12px;
    }

    .main-nav a:nth-child(3),
    .main-nav a:nth-child(4) {
        display: none;
    }

    .hero {
        padding: 55px 0 48px;
    }

    .hero-inner,
    .section-heading,
    .footer-inner {
        align-items: flex-start;
        flex-direction: column;
    }

    .hero-btn {
        width: 100%;
    }

    .summary-section,
    .setup-section,
    .budgets-section,
    .alerts-section {
        padding: 44px 0;
    }

    .summary-grid,
    .budget-grid,
    .budget-form {
        grid-template-columns: 1fr;
    }

    .form-btn {
        grid-column: auto;
    }

    .budget-form {
        padding: 20px;
    }

    .overview-details {
        grid-template-columns: 1fr;
    }

    .alert-info-strip,
    .footer-bottom {
        align-items: flex-start;
        flex-direction: column;
    }
}

@media (max-width: 480px) {
    .main-nav {
        display: none;
    }

    .header-inner {
        justify-content: space-between;
    }

    .stats-row {
        grid-template-columns: 1fr;
    }

    .spending-form,
    .card-actions {
        flex-direction: column;
    }

    .alert-item {
        align-items: flex-start;
        flex-direction: column;
    }

    .modal-actions {
        flex-direction: column-reverse;
    }

    .modal-actions button {
        width: 100%;
    }

    .empty-state,
    .empty-alerts {
        padding: 32px 20px;
    }
}</style>
<body>
    <header class="site-header">
        <div class="container header-inner">
            <a class="brand" href="#top">Campus Coin</a>
            <nav class="main-nav" aria-label="Main navigation">
                <a href="#overview">Overview</a>
                <a href="#setup">Setup</a>
                <a href="#budgets">Budgets</a>
                <a href="#alerts">Alerts</a>
            </nav>
            <button class="theme-btn" id="themeToggle" type="button">Dark</button>
        </div>
    </header>

    <main id="top">
        <section class="hero">
            <div class="container hero-inner">
                <div class="hero-copy">
                    <p class="eyebrow">Monthly Financial Planner</p>
                    <h1>Budget Goals & Alerts</h1>
                    <p>Plan your monthly spending, monitor every category, and stay aware of your budget limits.</p>
                </div>
                <button class="primary-btn hero-btn" id="openBudgetModal" type="button">Add New Budget</button>
            </div>
        </section>

        <section class="summary-section" id="overview">
            <div class="container">
                <div class="section-heading">
                    <div>
                        <p class="eyebrow">At a Glance</p>
                        <h2>Monthly overview</h2>
                    </div>
                    <p class="section-note">Your budget data is saved automatically on this device.</p>
                </div>

                <div class="summary-grid">
                    <article class="summary-card">
                        <div class="summary-icon">B</div>
                        <div>
                            <span>Total Monthly Budget</span>
                            <strong id="totalBudget">$0.00</strong>
                            <small>Across all categories</small>
                        </div>
                    </article>

                    <article class="summary-card">
                        <div class="summary-icon">S</div>
                        <div>
                            <span>Amount Spent</span>
                            <strong id="totalSpent">$0.00</strong>
                            <small>Recorded spending</small>
                        </div>
                    </article>

                    <article class="summary-card">
                        <div class="summary-icon">R</div>
                        <div>
                            <span>Total Remaining</span>
                            <strong id="totalRemaining">$0.00</strong>
                            <small>Available to spend</small>
                        </div>
                    </article>

                    <article class="summary-card">
                        <div class="summary-icon">U</div>
                        <div>
                            <span>Budget Usage</span>
                            <strong id="totalUsage">0%</strong>
                            <small>Overall monthly usage</small>
                        </div>
                    </article>
                </div>

                <div class="overview-panel">
                    <div>
                        <div class="panel-heading">
                            <div>
                                <p class="eyebrow">Spending Health</p>
                                <h3>Overall budget progress</h3>
                            </div>
                            <strong id="overviewUsageLabel">0%</strong>
                        </div>

                        <div class="progress-track large">
                            <div class="progress-fill" id="overviewProgress"></div>
                        </div>
                    </div>

                    <div class="overview-details">
                        <div>
                            <span>Budgeted</span>
                            <strong id="overviewBudget">$0.00</strong>
                        </div>
                        <div>
                            <span>Spent</span>
                            <strong id="overviewSpent">$0.00</strong>
                        </div>
                        <div>
                            <span>Remaining</span>
                            <strong id="overviewRemaining">$0.00</strong>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="setup-section" id="setup">
            <div class="container">
                <div class="section-heading">
                    <div>
                        <p class="eyebrow">Monthly Budget Setup</p>
                        <h2>Set a category budget</h2>
                        <p class="section-description">Create a spending limit for each part of your monthly budget.</p>
                    </div>
                    <button class="secondary-btn" id="openBudgetModalAlt" type="button">Open Budget Setup</button>
                </div>

                <form class="budget-form" id="budgetForm">
                    <div class="field">
                        <label for="category">Select Category</label>
                        <select id="category" required>
                            <option value="">Choose category</option>
                            <option value="Food">Food</option>
                            <option value="Transport">Transport</option>
                            <option value="Shopping">Shopping</option>
                            <option value="Entertainment">Entertainment</option>
                            <option value="Education">Education</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>

                    <div class="field">
                        <label for="budgetAmount">Enter Budget Amount</label>
                        <div class="money-input">
                            <span>$</span>
                            <input id="budgetAmount" type="number" min="0.01" step="0.01" placeholder="30.00" required>
                        </div>
                    </div>

                    <button class="primary-btn form-btn" type="submit">Save Budget</button>
                </form>

                <p class="form-message" id="formMessage"></p>
            </div>
        </section>

        <section class="budgets-section" id="budgets">
            <div class="container">
                <div class="section-heading">
                    <div>
                        <p class="eyebrow">Budget Overview</p>
                        <h2>Your monthly categories</h2>
                        <p class="section-description">Track what you planned, what you spent, and what is still available.</p>
                    </div>
                    <span class="count-label" id="budgetCount">0 categories</span>
                </div>

                <div class="budget-grid" id="budgetList"></div>

                <div class="empty-state" id="emptyState">
                    <div class="empty-icon">+</div>
                    <h3>No budgets yet</h3>
                    <p>Add a category budget to start tracking your monthly spending.</p>
                    <button class="secondary-btn" id="emptyAddBtn" type="button">Create Budget</button>
                </div>
            </div>
        </section>

        <section class="alerts-section" id="alerts">
            <div class="container">
                <div class="section-heading">
                    <div>
                        <p class="eyebrow">Budget Alerts</p>
                        <h2>Stay within your limits</h2>
                        <p class="section-description">Campus Coin automatically checks your spending and highlights categories that need attention.</p>
                    </div>
                    <button class="secondary-btn danger-outline" id="clearAlerts" type="button">Clear Alerts</button>
                </div>

                <div class="alert-info-strip">
                    <div>
                        <strong>Alert thresholds</strong>
                        <span>Near Budget Limit at 80% · Exceeded Budget at 100%</span>
                    </div>
                    <span class="alert-status">Automatic</span>
                </div>

                <div class="alert-list" id="alertList"></div>

                <div class="empty-alerts" id="emptyAlerts">
                    <div class="check-icon">✓</div>
                    <h3>Everything looks clear</h3>
                    <p>No active budget alerts right now.</p>
                </div>
            </div>
        </section>
    </main>

    <footer class="site-footer">
        <div class="container footer-inner">
            <div>
                <strong class="footer-brand">Campus Coin</strong>
                <p>Budget Goals & Alerts</p>
            </div>

            <div class="footer-links">
                <a href="#overview">Overview</a>
                <a href="#setup">Setup</a>
                <a href="#budgets">Budgets</a>
                <a href="#alerts">Alerts</a>
            </div>
        </div>

        <div class="container footer-bottom">
            <span>Personal budgeting made simple.</span>
            <span>Data stays in your browser.</span>
        </div>
    </footer>

    <div class="modal-backdrop" id="budgetModal" aria-hidden="true">
        <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
            <div class="modal-header">
                <div>
                    <p class="eyebrow">Budget Setup</p>
                    <h2 id="modalTitle">Add New Budget</h2>
                    <p>Create or update a monthly spending limit.</p>
                </div>
                <button class="close-btn" id="closeModal" type="button" aria-label="Close modal">×</button>
            </div>

            <form id="modalBudgetForm">
                <input type="hidden" id="editingId">

                <div class="field">
                    <label for="modalCategory">Select Category</label>
                    <select id="modalCategory" required>
                        <option value="">Choose category</option>
                        <option value="Food">Food</option>
                        <option value="Transport">Transport</option>
                        <option value="Shopping">Shopping</option>
                        <option value="Entertainment">Entertainment</option>
                        <option value="Education">Education</option>
                        <option value="Other">Other</option>
                    </select>
                </div>

                <div class="field">
                    <label for="modalAmount">Budget Amount</label>
                    <div class="money-input">
                        <span>$</span>
                        <input id="modalAmount" type="number" min="0.01" step="0.01" placeholder="30.00" required>
                    </div>
                </div>

                <p class="form-message" id="modalMessage"></p>

                <div class="modal-actions">
                    <button class="secondary-btn" id="cancelModal" type="button">Cancel</button>
                    <button class="primary-btn" type="submit" id="modalSubmit">Save Budget</button>
                </div>
            </form>
        </div>
    </div>

    <script src="js/script.js"></script>
</body>
</html>