<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Campus Coin - Dashboard</title>

    <!-- Font Awesome Icons -->
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background: #f4f8f5;
    color: #1f2937;
}

/* ================= HEADER ================= */

.header {
    height: 75px;
    background: #ffffff;
    border-bottom: 1px solid #dce7df;
    display: flex;
    align-items: center;
    padding: 0 30px;
    gap: 30px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
}

.logo {
    width: 245px;
    font-size: 26px;
    font-weight: bold;
    display: flex;
    align-items: center;
    gap: 12px;
    color: #14532d;
}

.logo i {
    font-size: 30px;
    color: #16a34a;
}

.search-box {
    flex: 1;
    max-width: 480px;
    position: relative;
}

.search-box input {
    width: 100%;
    height: 44px;
    border: 1px solid #cbd5cf;
    border-radius: 10px;
    padding: 0 45px;
    font-size: 15px;
    outline: none;
    background: #f8faf9;
}

.search-box input:focus {
    border-color: #16a34a;
    background: white;
}

.search-box i {
    position: absolute;
    left: 16px;
    top: 14px;
    color: #64748b;
}

.header-right {
    margin-left: auto;
    display: flex;
    align-items: center;
    gap: 25px;
}

.notification {
    position: relative;
    font-size: 21px;
    color: #334155;
    cursor: pointer;
}

.notification span {
    position: absolute;
    top: -9px;
    right: -10px;
    background: #16a34a;
    color: white;
    width: 19px;
    height: 19px;
    border-radius: 50%;
    font-size: 11px;
    display: flex;
    justify-content: center;
    align-items: center;
}

.profile {
    display: flex;
    align-items: center;
    gap: 10px;
    cursor: pointer;
    color: #334155;
}

.profile i:first-child {
    color: #15803d;
    font-size: 35px;
}

/* ================= MAIN ================= */

.layout {
    display: flex;
    min-height: calc(100vh - 75px);
}

/* ================= SIDEBAR ================= */

.sidebar {
    width: 245px;
    background: #123b2a;
    padding: 25px 15px;
}

.sidebar ul {
    list-style: none;
}

.sidebar li {
    margin-bottom: 7px;
}

.sidebar a {
    display: flex;
    align-items: center;
    gap: 17px;
    padding: 13px 15px;
    color: #dcefe3;
    text-decoration: none;
    border-radius: 8px;
    font-size: 16px;
    transition: 0.2s;
}

.sidebar a:hover {
    background: #1f6042;
    color: white;
}

.sidebar a.active {
    background: #22c55e;
    color: white;
    font-weight: bold;
}

.sidebar i {
    width: 23px;
    font-size: 19px;
}

/* ================= CONTENT ================= */

.content {
    flex: 1;
    padding: 30px;
    overflow-x: hidden;
}

.welcome-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 22px;
}

.welcome h1 {
    font-size: 28px;
    margin-bottom: 8px;
    color: #123b2a;
}

.welcome p {
    color: #64748b;
}

.month {
    border: 1px solid #cbd5cf;
    background: white;
    color: #334155;
    padding: 11px 15px;
    border-radius: 8px;
    cursor: pointer;
}

.month:hover {
    border-color: #16a34a;
    color: #15803d;
}

/* ================= CARDS ================= */

.cards {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 18px;
    margin-bottom: 20px;
}

.card {
    background: white;
    border: 1px solid #dce7df;
    border-radius: 12px;
    padding: 22px;
    min-height: 150px;
    box-shadow: 0 3px 12px rgba(20, 83, 45, 0.06);
    transition: 0.2s;
}

.card:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 18px rgba(20, 83, 45, 0.10);
}

.card-title {
    display: flex;
    align-items: center;
    gap: 12px;
    color: #64748b;
    margin-bottom: 15px;
}

.card-title i {
    font-size: 23px;
    color: #16a34a;
}

.card h2 {
    font-size: 23px;
    margin-bottom: 9px;
    color: #123b2a;
}

.card small {
    color: #16a34a;
}

/* ================= GRID ================= */

.two-column {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 18px;
    margin-bottom: 18px;
}

.box {
    background: white;
    border: 1px solid #dce7df;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 3px 12px rgba(20, 83, 45, 0.05);
}

.box h3 {
    margin-bottom: 20px;
    font-size: 19px;
    color: #123b2a;
}

/* ================= CHART ================= */

.chart {
    height: 220px;
    display: flex;
    align-items: end;
    justify-content: space-around;
    border-bottom: 1px solid #cbd5cf;
    padding: 10px 15px 0;
}

.month-column {
    height: 100%;
    display: flex;
    align-items: end;
    gap: 5px;
}

.bar {
    width: 16px;
    border-radius: 4px 4px 0 0;
}

.bar.income {
    background: #86efac;
}

.bar.expense {
    background: #15803d;
}

.chart-labels {
    display: flex;
    justify-content: space-around;
    margin-top: 8px;
    color: #64748b;
    font-size: 13px;
}

.legend {
    text-align: right;
    margin-bottom: 5px;
    font-size: 13px;
    color: #64748b;
}

/* ================= BUDGET ================= */

.budget-item {
    margin-bottom: 18px;
}

.budget-top {
    display: flex;
    justify-content: space-between;
    margin-bottom: 7px;
    font-size: 14px;
    color: #475569;
}

.progress {
    width: 100%;
    height: 9px;
    background: #e5eee8;
    border-radius: 10px;
    overflow: hidden;
}

.progress-bar {
    height: 100%;
    background: #22c55e;
    border-radius: 10px;
}

/* ================= QUICK ADD ================= */

.quick-buttons {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}

.quick-btn {
    min-height: 100px;
    border: 1px solid #cde3d4;
    background: #f0fdf4;
    color: #14532d;
    border-radius: 9px;
    cursor: pointer;
    font-size: 16px;
    transition: 0.2s;
}

.quick-btn:hover {
    background: #dcfce7;
    border-color: #22c55e;
    transform: translateY(-2px);
}

.quick-btn i {
    display: block;
    font-size: 22px;
    margin-bottom: 9px;
    color: #16a34a;
}

/* ================= SAVING TIPS ================= */

.tip {
    border: 1px solid #bbf7d0;
    background: #f0fdf4;
    border-radius: 9px;
    padding: 15px;
    display: flex;
    gap: 15px;
    align-items: center;
}

.tip i {
    font-size: 28px;
    color: #16a34a;
}

.tip p {
    margin-top: 6px;
    font-size: 13px;
    color: #64748b;
}

.view-all {
    float: right;
    color: #16a34a;
    text-decoration: none;
    font-size: 13px;
}

.view-all:hover {
    color: #14532d;
}

/* ================= TABLE ================= */

table {
    width: 100%;
    border-collapse: collapse;
}

th,
td {
    padding: 11px 8px;
    text-align: left;
    border-bottom: 1px solid #e2e8e5;
    font-size: 13px;
}

th {
    color: #475569;
    background: #f8faf9;
}

td {
    color: #475569;
}

/* ================= DONUT ================= */

.category-area {
    display: flex;
    align-items: center;
    gap: 25px;
}

.donut {
    width: 135px;
    height: 135px;
    border-radius: 50%;

    background: conic-gradient(
        #14532d 0deg 115deg,
        #22c55e 115deg 180deg,
        #4ade80 180deg 266deg,
        #86efac 266deg 302deg,
        #dcfce7 302deg 360deg
    );

    display: flex;
    justify-content: center;
    align-items: center;
}

.donut-center {
    width: 78px;
    height: 78px;
    background: white;
    border-radius: 50%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    font-size: 12px;
    color: #475569;
}

.category-list {
    list-style: none;
}

.category-list li {
    margin: 9px 0;
    font-size: 13px;
    color: #475569;
}

/* ================= MODAL ================= */

.modal {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(18, 59, 42, 0.55);
    justify-content: center;
    align-items: center;
    z-index: 1000;
}

.modal-box {
    background: white;
    width: 400px;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
}

.modal-box h2 {
    margin-bottom: 20px;
    color: #123b2a;
}

.modal-box input,
.modal-box select {
    width: 100%;
    padding: 11px;
    margin-bottom: 12px;
    border: 1px solid #cbd5cf;
    border-radius: 7px;
    outline: none;
}

.modal-box input:focus,
.modal-box select:focus {
    border-color: #22c55e;
}

.modal-buttons {
    display: flex;
    gap: 10px;
}

.modal-buttons button {
    flex: 1;
    padding: 11px;
    border: none;
    border-radius: 7px;
    cursor: pointer;
}

.add-btn {
    background: #15803d;
    color: white;
}

.add-btn:hover {
    background: #14532d;
}

.cancel-btn {
    background: #e2e8e5;
    color: #334155;
}

/* ================= RESPONSIVE ================= */

@media (max-width: 1100px) {

    .cards {
        grid-template-columns: repeat(2, 1fr);
    }

    .two-column {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 800px) {

    .header {
        padding: 0 15px;
    }

    .logo {
        width: auto;
    }

    .logo span {
        display: none;
    }

    .sidebar {
        width: 70px;
        padding: 20px 8px;
    }

    .sidebar a {
        justify-content: center;
        padding: 13px 5px;
    }

    .sidebar a span {
        display: none;
    }

    .sidebar i {
        width: auto;
    }

    .content {
        padding: 20px 15px;
    }
}

@media (max-width: 600px) {

    .cards {
        grid-template-columns: 1fr;
    }

    .search-box {
        display: none;
    }

    .header {
        gap: 10px;
    }

    .welcome-row {
        align-items: flex-start;
        gap: 15px;
        flex-direction: column;
    }

    .quick-buttons {
        grid-template-columns: 1fr;
    }

    .category-area {
        flex-direction: column;
    }
}
    </style>
</head>


<body>

    <!-- ================= HEADER ================= -->

    <header class="header">

        <div class="logo">
            <i class="fa-solid fa-coins"></i>
            <span>Campus Coin</span>
        </div>

        <div class="search-box">
            <i class="fa-solid fa-magnifying-glass"></i>
            <input type="text" placeholder="Search...">
        </div>

        <div class="header-right">

            <div class="notification">
                <i class="fa-regular fa-bell"></i>
                <span>2</span>
            </div>

            <div class="profile">
                <i class="fa-regular fa-circle-user"></i>
                <span>Student</span>
                <i class="fa-solid fa-chevron-down"></i>
            </div>

        </div>

    </header>


    <div class="layout">

        <!-- ================= SIDEBAR ================= -->

        <aside class="sidebar">

            <ul>

                <li>
                    <a href="#" class="active">
                        <i class="fa-solid fa-house"></i>
                        <span>Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <i class="fa-solid fa-arrow-right-arrow-left"></i>
                        <span>Transactions</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <i class="fa-regular fa-folder"></i>
                        <span>Categories</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <i class="fa-solid fa-bullseye"></i>
                        <span>Budget Goals</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <i class="fa-solid fa-chart-column"></i>
                        <span>Reports</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <i class="fa-regular fa-lightbulb"></i>
                        <span>Saving Tips</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <i class="fa-solid fa-robot"></i>
                        <span>AI Insights</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <i class="fa-regular fa-bookmark"></i>
                        <span>Bookmarks</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <i class="fa-solid fa-cloud-arrow-up"></i>
                        <span>Import Transactions</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <i class="fa-regular fa-user"></i>
                        <span>Profile</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <i class="fa-solid fa-gear"></i>
                        <span>Settings</span>
                    </a>
                </li>

                <li>
                    <a href="#">
                        <i class="fa-solid fa-right-from-bracket"></i>
                        <span>Logout</span>
                    </a>
                </li>

            </ul>

        </aside>


        <!-- ================= DASHBOARD ================= -->

        <main class="content">

            <div class="welcome-row">

                <div class="welcome">

                    <h1>Welcome back, Student!</h1>

                    <p>
                        Here's your financial overview for this month.
                    </p>

                </div>

                <button class="month">
                    <i class="fa-regular fa-calendar"></i>
                    September 2026
                    <i class="fa-solid fa-chevron-down"></i>
                </button>

            </div>


            <!-- ================= CARDS ================= -->

            <div class="cards">

                <div class="card">

                    <div class="card-title">
                        <i class="fa-solid fa-wallet"></i>
                        <span>Current Balance</span>
                    </div>

                    <h2>Rs. 12,450</h2>

                    <small>↑ 12% from last month</small>

                </div>


                <div class="card">

                    <div class="card-title">
                        <i class="fa-solid fa-arrow-down"></i>
                        <span>Total Income</span>
                    </div>

                    <h2>Rs. 25,000</h2>

                    <small>↑ 8% from last month</small>

                </div>


                <div class="card">

                    <div class="card-title">
                        <i class="fa-solid fa-arrow-up"></i>
                        <span>Total Expenses</span>
                    </div>

                    <h2>Rs. 12,550</h2>

                    <small>↓ 5% from last month</small>

                </div>


                <div class="card">

                    <div class="card-title">
                        <i class="fa-regular fa-star"></i>
                        <span>Top Category</span>
                    </div>

                    <h2>Food & Dining</h2>

                    <small>32% of expenses</small>

                </div>

            </div>


            <!-- ================= CHART + BUDGET ================= -->

            <div class="two-column">

                <div class="box">

                    <h3>Monthly Spending Overview</h3>

                    <div class="legend">
                        ▢ Income &nbsp;&nbsp; ▣ Expenses
                    </div>

                    <div class="chart">

                        <div class="month-column">
                            <div class="bar income" style="height: 110px;"></div>
                            <div class="bar expense" style="height: 75px;"></div>
                        </div>

                        <div class="month-column">
                            <div class="bar income" style="height: 125px;"></div>
                            <div class="bar expense" style="height: 85px;"></div>
                        </div>

                        <div class="month-column">
                            <div class="bar income" style="height: 140px;"></div>
                            <div class="bar expense" style="height: 95px;"></div>
                        </div>

                        <div class="month-column">
                            <div class="bar income" style="height: 130px;"></div>
                            <div class="bar expense" style="height: 92px;"></div>
                        </div>

                        <div class="month-column">
                            <div class="bar income" style="height: 150px;"></div>
                            <div class="bar expense" style="height: 100px;"></div>
                        </div>

                        <div class="month-column">
                            <div class="bar income" style="height: 130px;"></div>
                            <div class="bar expense" style="height: 95px;"></div>
                        </div>

                    </div>

                    <div class="chart-labels">
                        <span>Apr</span>
                        <span>May</span>
                        <span>Jun</span>
                        <span>Jul</span>
                        <span>Aug</span>
                        <span>Sep</span>
                    </div>

                </div>


                <div class="box">

                    <h3>Budget vs Actual</h3>

                    <div class="budget-item">

                        <div class="budget-top">
                            <span>🍴 Food & Dining</span>
                            <span>Rs. 4,000 / 5,000</span>
                        </div>

                        <div class="progress">
                            <div class="progress-bar" style="width:80%;"></div>
                        </div>

                    </div>


                    <div class="budget-item">

                        <div class="budget-top">
                            <span>🚌 Transport</span>
                            <span>Rs. 1,500 / 2,000</span>
                        </div>

                        <div class="progress">
                            <div class="progress-bar" style="width:75%;"></div>
                        </div>

                    </div>


                    <div class="budget-item">

                        <div class="budget-top">
                            <span>🏠 Hostel / Rent</span>
                            <span>Rs. 3,000 / 5,000</span>
                        </div>

                        <div class="progress">
                            <div class="progress-bar" style="width:60%;"></div>
                        </div>

                    </div>


                    <div class="budget-item">

                        <div class="budget-top">
                            <span>📚 Academics</span>
                            <span>Rs. 1,200 / 3,000</span>
                        </div>

                        <div class="progress">
                            <div class="progress-bar" style="width:40%;"></div>
                        </div>

                    </div>

                </div>

            </div>


            <!-- ================= QUICK ADD + SAVING TIPS ================= -->

            <div class="two-column">

                <div class="box">

                    <h3>Quick Add</h3>

                    <div class="quick-buttons">

                        <button class="quick-btn" onclick="openModal('income')">

                            <i class="fa-solid fa-plus"></i>

                            Add Income

                            <br>

                            <small>
                                Allowance, Job, Scholarship, Gift
                            </small>

                        </button>


                        <button class="quick-btn" onclick="openModal('expense')">

                            <i class="fa-solid fa-plus"></i>

                            Add Expense

                            <br>

                            <small>
                                Food, Transport, Hostel, etc.
                            </small>

                        </button>

                    </div>

                </div>


                <div class="box">

                    <h3>
                        Saving Tips

                        <a href="#" class="view-all">
                            View All →
                        </a>
                    </h3>

                    <div class="tip">

                        <i class="fa-regular fa-lightbulb"></i>

                        <div>

                            <strong>
                                Try cooking at home more often.
                            </strong>

                            <p>
                                You can save up to Rs. 1,500 this month!
                            </p>

                        </div>

                    </div>

                </div>

            </div>


            <!-- ================= TRANSACTIONS + CATEGORY ================= -->

            <div class="two-column">

                <div class="box">

                    <h3>
                        Recent Transactions

                        <a href="#" class="view-all">
                            View All →
                        </a>
                    </h3>

                    <table>

                        <thead>

                            <tr>
                                <th>Date</th>
                                <th>Description</th>
                                <th>Category</th>
                                <th>Amount</th>
                                <th>Type</th>
                            </tr>

                        </thead>

                        <tbody>

                            <tr>
                                <td>12 Sep</td>
                                <td>Hostel Fee</td>
                                <td>Hostel / Rent</td>
                                <td>- Rs. 3,000</td>
                                <td>Expense</td>
                            </tr>

                            <tr>
                                <td>10 Sep</td>
                                <td>Part-time Job</td>
                                <td>Job Income</td>
                                <td>+ Rs. 5,000</td>
                                <td>Income</td>
                            </tr>

                            <tr>
                                <td>08 Sep</td>
                                <td>Lunch</td>
                                <td>Food</td>
                                <td>- Rs. 500</td>
                                <td>Expense</td>
                            </tr>

                        </tbody>

                    </table>

                </div>


                <div class="box">

                    <h3>This Month's Categories</h3>

                    <div class="category-area">

                        <div class="donut">

                            <div class="donut-center">
                                <strong>Total</strong>
                                Rs. 12,550
                            </div>

                        </div>


                        <ul class="category-list">

                            <li>● Food & Dining — 32%</li>
                            <li>● Transport — 18%</li>
                            <li>● Hostel / Rent — 24%</li>
                            <li>● Academics — 10%</li>
                            <li>● Others — 16%</li>

                        </ul>

                    </div>

                </div>

            </div>

        </main>

    </div>


    <!-- ================= ADD TRANSACTION MODAL ================= -->

    <div class="modal" id="transactionModal">

        <div class="modal-box">

            <h2 id="modalTitle">Add Income</h2>

            <input type="number" placeholder="Enter Amount">

            <input type="text" placeholder="Description">

            <select>
                <option>Select Category</option>
                <option>Allowance</option>
                <option>Part-time Job</option>
                <option>Scholarship</option>
                <option>Food</option>
                <option>Transport</option>
                <option>Hostel / Rent</option>
            </select>

            <input type="date">

            <div class="modal-buttons">

                <button class="add-btn" onclick="saveTransaction()">
                    Add Transaction
                </button>

                <button class="cancel-btn" onclick="closeModal()">
                    Cancel
                </button>

            </div>

        </div>

    </div>


    <!-- ================= JAVASCRIPT ================= -->

    <script>

        function openModal(type) {

            document.getElementById("transactionModal").style.display = "flex";

            if (type === "income") {
                document.getElementById("modalTitle").innerText = "Add Income";
            }

            if (type === "expense") {
                document.getElementById("modalTitle").innerText = "Add Expense";
            }
        }


        function closeModal() {

            document.getElementById("transactionModal").style.display = "none";

        }


        function saveTransaction() {

            alert("Transaction added successfully!");

            closeModal();

        }


        /* Sidebar active link */

        const sidebarLinks = document.querySelectorAll(".sidebar a");

        sidebarLinks.forEach(function(link) {

            link.addEventListener("click", function() {

                sidebarLinks.forEach(function(item) {
                    item.classList.remove("active");
                });

                this.classList.add("active");

            });

        });


        /* Close modal when clicking outside */

        window.addEventListener("click", function(event) {

            const modal = document.getElementById("transactionModal");

            if (event.target === modal) {
                closeModal();
            }

        });

    </script>

</body>

</html>