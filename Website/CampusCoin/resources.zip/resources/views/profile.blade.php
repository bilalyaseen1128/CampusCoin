<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CampusCoin | Profile</title>
    <link rel="stylesheet" href="categories.css">
</head>
<body>

<div class="app">

    <aside class="sidebar" id="sidebar">
        <div class="logo-area">
            <div class="logo">
                <div class="logo-icon">C</div>
                <div class="logo-text">
                    <h2>CampusCoin</h2>
                    <span>Student Finance</span>
                </div>
            </div>
        </div>

        <div class="nav-title">Main Menu</div>

        <nav class="nav-menu">
            <a href="dashboard.html" class="nav-link"><span class="nav-icon">⌂</span>Dashboard</a>
            <a href="income-expenses.html" class="nav-link"><span class="nav-icon">↕</span>Income & Expenses</a>
            <a href="categories.html" class="nav-link"><span class="nav-icon">▦</span>Categories</a>
            <a href="budget-goals.html" class="nav-link"><span class="nav-icon">◈</span>Budget Goals</a>
            <a href="reports-insights.html" class="nav-link"><span class="nav-icon">▥</span>Reports & Insights</a>
            <a href="saving-tips.html" class="nav-link"><span class="nav-icon">★</span>Saving Tips</a>
        </nav>

        <div class="sidebar-bottom">
            <nav class="nav-menu">
                <a href="profile.html" class="nav-link"><span class="nav-icon">◯</span>Profile</a>
                <a href="dashboard.html" class="nav-link"><span class="nav-icon">↪</span>Logout</a>
            </nav>
        </div>
    </aside>

    <main class="main">

        <header class="topbar">
            <button class="menu-btn" id="menuButton">☰</button>

            <div class="topbar-right">
                <button class="theme-btn" id="themeButton">☾</button>

                <div class="user-mini">
                    <div class="avatar">H</div>
                    <span>Student</span>
                </div>
            </div>
        </header>

        <section class="content">

            <div class="page-heading">
                <h1>My Profile</h1>
                <p>Manage your CampusCoin account information.</p>
            </div>

            <div class="card profile-card">

                <div class="profile-header">
                    <div class="profile-avatar">H</div>

                    <div>
                        <h2>Hareem Khan</h2>
                        <p>Student Account</p>
                    </div>
                </div>

                <form>

                    <div class="form-grid">

                        <div class="form-group">
                            <label>Full Name</label>
                            <input type="text" value="Hareem Khan">
                        </div>

                        <div class="form-group">
                            <label>Email Address</label>
                            <input type="email" value="hareem@example.com">
                        </div>

                        <div class="form-group">
                            <label>Phone Number</label>
                            <input type="text" value="0300 1234567">
                        </div>

                        <div class="form-group">
                            <label>Student ID</label>
                            <input type="text" value="CC-2026-001">
                        </div>

                        <div class="form-group">
                            <label>University / College</label>
                            <input type="text" value="Student">
                        </div>

                        <div class="form-group">
                            <label>Currency</label>
                            <select>
                                <option>Pakistani Rupee (₨)</option>
                                <option>US Dollar ($)</option>
                                <option>Euro (€)</option>
                            </select>
                        </div>

                    </div>

                    <div style="margin-top:22px;">
                        <button type="button" class="btn btn-primary">Save Changes</button>
                    </div>

                </form>

            </div>

        </section>
    </main>
</div>

<script src="script.js"></script>
</body>
</html>