<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CampusCoin | Dashboard</title>
    <link rel="stylesheet" href="css/categories.css">
</head>
<body>

<div class="app">

    <aside class="sidebar" id="sidebar">
        <div class="logo-area">
            <div class="logo">
                <div class="logo-icon">C</div>
                <div class="logo-text">
                    <h2>CampusCoin</h2>
                    <span>Student Finance</span>
                </div>
            </div>
        </div>

        <div class="nav-title">Main Menu</div>

        <nav class="nav-menu">
            <a href="dashboard.html" class="nav-link">
                <span class="nav-icon">⌂</span>
                Dashboard
            </a>

            <a href="income-expenses.html" class="nav-link">
                <span class="nav-icon">↕</span>
                Income & Expenses
            </a>

            <a href="categories.html" class="nav-link">
                <span class="nav-icon">▦</span>
                Categories
            </a>

            <a href="budget-goals.html" class="nav-link">
                <span class="nav-icon">◈</span>
                Budget Goals
            </a>

            <a href="reports-insights.html" class="nav-link">
                <span class="nav-icon">▥</span>
                Reports & Insights
            </a>

            <a href="saving-tips.html" class="nav-link">
                <span class="nav-icon">★</span>
                Saving Tips
            </a>
        </nav>

        <div class="sidebar-bottom">
            <nav class="nav-menu">
                <a href="profile.html" class="nav-link">
                    <span class="nav-icon">◯</span>
                    Profile
                </a>

                <a href="dashboard.html" class="nav-link" onclick="return confirm('Are you sure you want to logout?')">
                    <span class="nav-icon">↪</span>
                    Logout
                </a>
            </nav>
        </div>
    </aside>

    <main class="main">

        <header class="topbar">
            <button class="menu-btn" id="menuButton">☰</button>

            <div class="topbar-right">
                <button class="theme-btn" id="themeButton">☾</button>

                <div class="user-mini">
                    <div class="avatar">H</div>
                    <span>Student</span>
                </div>
            </div>
        </header>

        <section class="content">

            <div class="page-heading">
                <h1>Welcome back 👋</h1>
                <p>Here's an overview of your student finances.</p>
            </div>

            <div class="stats-grid">

                <div class="stat-card">
                    <div class="stat-top">
                        <span class="stat-icon">₨</span>
                        <span class="stat-change income">+8.2%</span>
                    </div>
                    <h3>₨45,000</h3>
                    <p>Total Income</p>
                </div>

                <div class="stat-card">
                    <div class="stat-top">
                        <span class="stat-icon">↓</span>
                        <span class="stat-change expense">+4.5%</span>
                    </div>
                    <h3>₨28,450</h3>
                    <p>Total Expenses</p>
                </div>

                <div class="stat-card">
                    <div class="stat-top">
                        <span class="stat-icon">◈</span>
                        <span class="stat-change income">12%</span>
                    </div>
                    <h3>₨16,550</h3>
                    <p>Current Balance</p>
                </div>

                <div class="stat-card">
                    <div class="stat-top">
                        <span class="stat-icon">★</span>
                        <span class="stat-change warning">65%</span>
                    </div>
                    <h3>₨10,750</h3>
                    <p>Budget Remaining</p>
                </div>

            </div>

            <div class="dashboard-grid">

                <div class="card">
                    <div class="card-header">
                        <h2>Monthly Expenses</h2>
                        <a href="reports-insights.html">View Reports</a>
                    </div>

                    <div class="chart">
                        <div class="bar-wrapper">
                            <div class="bar" style="height: 45%"></div>
                            <span>Jan</span>
                        </div>

                        <div class="bar-wrapper">
                            <div class="bar" style="height: 60%"></div>
                            <span>Feb</span>
                        </div>

                        <div class="bar-wrapper">
                            <div class="bar" style="height: 42%"></div>
                            <span>Mar</span>
                        </div>

                        <div class="bar-wrapper">
                            <div class="bar" style="height: 75%"></div>
                            <span>Apr</span>
                        </div>

                        <div class="bar-wrapper">
                            <div class="bar" style="height: 55%"></div>
                            <span>May</span>
                        </div>

                        <div class="bar-wrapper">
                            <div class="bar" style="height: 68%"></div>
                            <span>Jun</span>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h2>Recent Transactions</h2>
                        <a href="income-expenses.html">View All</a>
                    </div>

                    <div class="transaction-list">

                        <div class="transaction">
                            <div class="transaction-info">
                                <div class="transaction-icon">🍔</div>
                                <div>
                                    <div class="transaction-name">Food</div>
                                    <div class="transaction-date">Today</div>
                                </div>
                            </div>
                            <div class="amount expense">-₨850</div>
                        </div>

                        <div class="transaction">
                            <div class="transaction-info">
                                <div class="transaction-icon">📚</div>
                                <div>
                                    <div class="transaction-name">Books</div>
                                    <div class="transaction-date">Yesterday</div>
                                </div>
                            </div>
                            <div class="amount expense">-₨1,500</div>
                        </div>

                        <div class="transaction">
                            <div class="transaction-info">
                                <div class="transaction-icon">💰</div>
                                <div>
                                    <div class="transaction-name">Allowance</div>
                                    <div class="transaction-date">20 Sep</div>
                                </div>
                            </div>
                            <div class="amount income">+₨10,000</div>
                        </div>

                        <div class="transaction">
                            <div class="transaction-info">
                                <div class="transaction-icon">🚌</div>
                                <div>
                                    <div class="transaction-name">Transport</div>
                                    <div class="transaction-date">18 Sep</div>
                                </div>
                            </div>
                            <div class="amount expense">-₨700</div>
                        </div>

                    </div>
                </div>

            </div>

        </section>
    </main>

</div>

<script src="script.js"></script>
</body>
</html>